# Database Schema

## Core Tables

### users
```sql
id                UUID PRIMARY KEY DEFAULT gen_random_uuid()
email             VARCHAR(255) UNIQUE NOT NULL
password_hash     VARCHAR(255) NOT NULL
first_name        VARCHAR(100) NOT NULL
last_name         VARCHAR(100) NOT NULL
role              user_role NOT NULL DEFAULT 'user'
department        VARCHAR(100)
approval_limit    DECIMAL(12,2) DEFAULT 0
is_active         BOOLEAN DEFAULT true
last_login        TIMESTAMP
created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

### vendors
```sql
id                UUID PRIMARY KEY DEFAULT gen_random_uuid()
name              VARCHAR(255) NOT NULL
email             VARCHAR(255)
phone             VARCHAR(50)
address_line1     VARCHAR(255)
address_line2     VARCHAR(255)
city              VARCHAR(100)
state             VARCHAR(50)
zip_code          VARCHAR(20)
country           VARCHAR(100) DEFAULT 'USA'
tax_id            VARCHAR(50)
payment_terms     INTEGER DEFAULT 30
is_approved       BOOLEAN DEFAULT false
risk_score        INTEGER DEFAULT 0
created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

### invoices
```sql
id                UUID PRIMARY KEY DEFAULT gen_random_uuid()
invoice_number    VARCHAR(100) NOT NULL
vendor_id         UUID REFERENCES vendors(id)
amount            DECIMAL(12,2) NOT NULL
tax_amount        DECIMAL(12,2) DEFAULT 0
total_amount      DECIMAL(12,2) NOT NULL
currency          VARCHAR(3) DEFAULT 'USD'
invoice_date      DATE NOT NULL
due_date          DATE NOT NULL
description       TEXT
po_number         VARCHAR(100)
department        VARCHAR(100)
category          VARCHAR(100)
status            invoice_status DEFAULT 'pending'
priority          priority_level DEFAULT 'medium'
confidence_score  INTEGER DEFAULT 0
ai_extracted_data JSONB
original_file_url VARCHAR(500)
processed_file_url VARCHAR(500)
submitted_by      UUID REFERENCES users(id)
assigned_to       UUID REFERENCES users(id)
created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

### approval_workflows
```sql
id                UUID PRIMARY KEY DEFAULT gen_random_uuid()
invoice_id        UUID REFERENCES invoices(id) ON DELETE CASCADE
approver_id       UUID REFERENCES users(id)
step_number       INTEGER NOT NULL
action            workflow_action NOT NULL
timestamp         TIMESTAMP DEFAULT CURRENT_TIMESTAMP
notes             TEXT
ip_address        INET
user_agent        TEXT
```

### purchase_orders
```sql
id                UUID PRIMARY KEY DEFAULT gen_random_uuid()
po_number         VARCHAR(100) UNIQUE NOT NULL
vendor_id         UUID REFERENCES vendors(id)
amount            DECIMAL(12,2) NOT NULL
department        VARCHAR(100)
requestor_id      UUID REFERENCES users(id)
status            po_status DEFAULT 'open'
created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

## Enums
```sql
CREATE TYPE user_role AS ENUM ('admin', 'manager', 'user', 'viewer');
CREATE TYPE invoice_status AS ENUM ('pending', 'in_review', 'approved', 'rejected', 'paid', 'cancelled');
CREATE TYPE priority_level AS ENUM ('low', 'medium', 'high', 'urgent');
CREATE TYPE workflow_action AS ENUM ('submit', 'approve', 'reject', 'request_info', 'escalate');
CREATE TYPE po_status AS ENUM ('open', 'partially_received', 'closed', 'cancelled');
```

## Indexes
```sql
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_invoices_vendor ON invoices(vendor_id);
CREATE INDEX idx_invoices_due_date ON invoices(due_date);
CREATE INDEX idx_invoices_amount ON invoices(amount);
CREATE INDEX idx_approval_workflows_invoice ON approval_workflows(invoice_id);
CREATE INDEX idx_vendors_name ON vendors(name);
```
