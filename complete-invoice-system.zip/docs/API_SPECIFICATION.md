# API Specification

## Authentication Endpoints

### POST /api/auth/login
```json
Request:
{
  "email": "user@company.com",
  "password": "securePassword123"
}

Response:
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid",
      "email": "user@company.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "manager",
      "department": "Finance"
    },
    "token": "jwt_token_here",
    "refreshToken": "refresh_token_here"
  }
}
```

### POST /api/auth/refresh
```json
Request:
{
  "refreshToken": "refresh_token_here"
}

Response:
{
  "success": true,
  "data": {
    "token": "new_jwt_token",
    "refreshToken": "new_refresh_token"
  }
}
```

## Invoice Endpoints

### GET /api/invoices
```
Query Parameters:
- status: pending|in_review|approved|rejected (optional)
- vendor: vendor_id (optional)
- department: string (optional)
- priority: low|medium|high|urgent (optional)
- limit: number (default: 25, max: 100)
- offset: number (default: 0)
- sortBy: created_at|due_date|amount (default: created_at)
- sortOrder: asc|desc (default: desc)

Response:
{
  "success": true,
  "data": {
    "invoices": [...],
    "pagination": {
      "total": 150,
      "limit": 25,
      "offset": 0,
      "hasMore": true
    }
  }
}
```

### POST /api/invoices
```json
Request (multipart/form-data):
{
  "file": "invoice.pdf",
  "metadata": {
    "department": "Operations",
    "priority": "medium"
  }
}

Response:
{
  "success": true,
  "data": {
    "invoice": {
      "id": "uuid",
      "invoiceNumber": "INV-2024-001",
      "vendor": {...},
      "amount": 1247.50,
      "dueDate": "2024-07-15",
      "status": "pending",
      "confidenceScore": 97,
      "aiExtractedData": {...}
    }
  }
}
```

### PUT /api/invoices/:id/approve
```json
Request:
{
  "notes": "Approved for payment"
}

Response:
{
  "success": true,
  "data": {
    "invoice": {...},
    "workflow": {
      "action": "approve",
      "approver": {...},
      "timestamp": "2024-06-25T10:30:00Z"
    }
  }
}
```

## Error Responses
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": {
      "field": "amount",
      "message": "Amount must be greater than 0"
    }
  }
}
```
