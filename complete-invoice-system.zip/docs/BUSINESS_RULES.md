# Business Rules

## Approval Workflow Rules

### Amount-Based Routing
- Amount ≤ $500: Department Manager approval required
- Amount $501-$5,000: Director approval required
- Amount $5,001-$25,000: VP approval required
- Amount > $25,000: CFO approval required

### Department-Specific Rules
- IT purchases > $1,000: CTO approval required
- Marketing expenses > $2,000: CMO approval required
- Consulting services: Department head + Finance approval
- Capital expenditures > $10,000: Executive team approval

### Vendor Validation Rules
- New vendors: Additional verification required
- Unapproved vendors: Auto-reject with notification
- High-risk vendors: Enhanced due diligence
- Vendor blacklist: Immediate rejection

### PO Matching Rules
- 3-way matching: PO + Invoice + Receipt required for >$1,000
- PO amount variance >10%: Flag for review
- Missing PO for amounts >$500: Require justification
- Closed PO: Reject new invoices

## AI Validation Rules

### Data Extraction Confidence
- Confidence ≥ 95%: Auto-process
- Confidence 85-94%: Flag for human review
- Confidence < 85%: Require manual data entry

### Anomaly Detection
- Duplicate invoice numbers: Flag and hold
- Unusual amount patterns: Flag for review
- Weekend/holiday submissions: Enhanced scrutiny
- Multiple invoices from same vendor: Check for duplicates

## Escalation Rules

### Time-Based Escalation
- No action in 24 hours: Notify approver
- No action in 48 hours: Escalate to manager
- No action in 72 hours: Escalate to executive
- Critical invoices: 4-hour escalation window

### Priority Escalation
- Urgent priority: Immediate notification
- High priority: 2-hour response window
- Medium priority: 24-hour response window
- Low priority: 48-hour response window
