# UI Components Specification

## Layout Components

### AppLayout
```tsx
interface AppLayoutProps {
  children: React.ReactNode;
  title?: string;
}

Features:
- Responsive sidebar navigation
- Header with user profile and notifications
- Breadcrumb navigation
- Mobile-friendly hamburger menu
- Real-time notification badges
```

### InvoiceCard
```tsx
interface InvoiceCardProps {
  invoice: Invoice;
  onApprove: (id: string, notes?: string) => void;
  onReject: (id: string, reason: string, notes?: string) => void;
  onView: (id: string) => void;
  compact?: boolean;
}

Features:
- Vendor logo or initial avatar
- Priority indicator badge
- AI confidence score
- Amount highlighting with currency formatting
- Due date with urgency color coding
- One-click approve/reject buttons
- Expandable details section
- Mobile-responsive design
- Loading states for actions
- Success/error animations
```

### Dashboard Components

#### StatsCard
```tsx
interface StatsCardProps {
  title: string;
  value: string | number;
  change?: number;
  icon?: React.ReactNode;
  color?: 'blue' | 'green' | 'red' | 'yellow';
  loading?: boolean;
}

Features:
- Animated counters
- Trend indicators
- Icon support
- Color theming
- Loading states
- Responsive design
```

### Form Components

#### InvoiceUpload
```tsx
interface InvoiceUploadProps {
  onUpload: (files: File[], metadata: UploadMetadata) => void;
  maxFiles?: number;
  acceptedTypes?: string[];
  maxSize?: number;
}

Features:
- Drag and drop interface
- Multiple file support
- File type validation
- Size limit checking
- Preview thumbnails
- Progress indicators
- Error messaging
- Metadata form fields
```

## Design System
- **Colors**: Blue primary (#3498db), Green success (#27ae60), Red danger (#e74c3c)
- **Typography**: Inter font family, responsive sizing
- **Spacing**: 8px base unit system
- **Breakpoints**: Mobile (640px), Tablet (768px), Desktop (1024px)
- **Animations**: Smooth transitions (300ms ease-in-out)
