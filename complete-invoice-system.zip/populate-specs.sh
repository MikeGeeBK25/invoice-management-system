y
#!/bin/bash

# Invoice Manager Specifications Population Script
# This script creates all the markdown specification files for Claude Developer

echo "🚀 Populating Invoice Manager Specifications..."

# Create PROJECT_OVERVIEW.md
cat > docs/PROJECT_OVERVIEW.md << 'EOF'
# Project Overview - Invoice Management System

## Core Objectives
- **Efficiency**: Process invoices 90% faster than manual methods
- **Accuracy**: Achieve 99% data accuracy through AI validation
- **Integration**: Seamlessly connect with existing accounting systems
- **Workflow**: Provide real-time approval workflows with mobile access
- **Compliance**: Maintain complete audit trails for financial compliance

## Success Metrics
- Average processing time: <2 hours (down from 5-7 days)
- User adoption rate: >95%
- Data accuracy: >99%
- Error rate: <1%
- Customer satisfaction: 4.5/5 stars

## Target Users
- **CFOs**: High-level approval and analytics
- **Finance Managers**: Day-to-day approval workflows
- **AP Clerks**: Invoice processing and data entry
- **Department Heads**: Budget approval and oversight

## Key Features
- AI-powered invoice data extraction
- Mobile-responsive approval interface
- Real-time notifications and updates
- ERP/accounting system integration
- Advanced analytics and reporting
- Multi-level approval workflows
- Vendor management and validation

## Business Value
- **Cost Reduction**: 80% reduction in manual processing costs
- **Time Savings**: 5-7 days reduced to 2 hours average processing
- **Error Prevention**: AI validation prevents costly mistakes
- **Compliance**: Automated audit trails and SOX compliance
- **Cash Flow**: Faster processing improves vendor relationships
- **Scalability**: Handle 10x volume without additional staff
EOF

# Create TECHNICAL_ARCHITECTURE.md
cat > docs/TECHNICAL_ARCHITECTURE.md << 'EOF'
# Technical Architecture

## Frontend Stack
```
React 18.2+ with TypeScript 5.0+
├── UI Framework: Tailwind CSS 3.0
├── State Management: React Query + Zustand
├── Real-time: Socket.io Client
├── Forms: React Hook Form + Zod validation
├── Charts: Recharts
├── Icons: Lucide React
├── Date Handling: date-fns
├── File Upload: React Dropzone
└── Testing: Jest + React Testing Library
```

## Backend Stack
```
Node.js 18+ with Express.js
├── Language: TypeScript
├── Database: PostgreSQL 15+ with Prisma ORM
├── Authentication: JWT + Passport.js
├── File Storage: AWS S3 or Azure Blob Storage
├── Caching: Redis
├── Real-time: Socket.io
├── Email: SendGrid or AWS SES
├── OCR: AWS Textract or Azure Form Recognizer
├── API Documentation: Swagger/OpenAPI
└── Testing: Jest + Supertest
```

## Infrastructure
```
Cloud Platform: AWS or Azure
├── Compute: Docker containers on ECS/AKS
├── Database: Managed PostgreSQL (RDS/Azure Database)
├── Cache: Managed Redis (ElastiCache/Azure Cache)
├── Storage: S3/Azure Blob Storage
├── CDN: CloudFront/Azure CDN
├── Load Balancer: ALB/Azure Load Balancer
├── Monitoring: CloudWatch/Azure Monitor
└── CI/CD: GitHub Actions
```

## Security Standards
- SOC 2 Type II compliance
- HIPAA compliance (if handling healthcare invoices)
- Data encryption at rest and in transit
- Role-based access control (RBAC)
- Multi-factor authentication (MFA)
- API rate limiting and throttling

## Performance Requirements
- Page load time: <2 seconds
- OCR processing: <30 seconds
- Real-time updates: <1 second latency
- Concurrent users: 100+
- Uptime SLA: 99.9%
EOF

# Create DATABASE_SCHEMA.md
cat > docs/DATABASE_SCHEMA.md << 'EOF'
# Database Schema

## Core Tables

### users
```sql
id                UUID PRIMARY KEY DEFAULT gen_random_uuid()
email             VARCHAR(255) UNIQUE NOT NULL
password_hash     VARCHAR(255) NOT NULL
first_name        VARCHAR(100) NOT NULL
last_name         VARCHAR(100) NOT NULL
role              user_role NOT NULL DEFAULT 'user'
department        VARCHAR(100)
approval_limit    DECIMAL(12,2) DEFAULT 0
is_active         BOOLEAN DEFAULT true
last_login        TIMESTAMP
created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

### vendors
```sql
id                UUID PRIMARY KEY DEFAULT gen_random_uuid()
name              VARCHAR(255) NOT NULL
email             VARCHAR(255)
phone             VARCHAR(50)
address_line1     VARCHAR(255)
address_line2     VARCHAR(255)
city              VARCHAR(100)
state             VARCHAR(50)
zip_code          VARCHAR(20)
country           VARCHAR(100) DEFAULT 'USA'
tax_id            VARCHAR(50)
payment_terms     INTEGER DEFAULT 30
is_approved       BOOLEAN DEFAULT false
risk_score        INTEGER DEFAULT 0
created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

### invoices
```sql
id                UUID PRIMARY KEY DEFAULT gen_random_uuid()
invoice_number    VARCHAR(100) NOT NULL
vendor_id         UUID REFERENCES vendors(id)
amount            DECIMAL(12,2) NOT NULL
tax_amount        DECIMAL(12,2) DEFAULT 0
total_amount      DECIMAL(12,2) NOT NULL
currency          VARCHAR(3) DEFAULT 'USD'
invoice_date      DATE NOT NULL
due_date          DATE NOT NULL
description       TEXT
po_number         VARCHAR(100)
department        VARCHAR(100)
category          VARCHAR(100)
status            invoice_status DEFAULT 'pending'
priority          priority_level DEFAULT 'medium'
confidence_score  INTEGER DEFAULT 0
ai_extracted_data JSONB
original_file_url VARCHAR(500)
processed_file_url VARCHAR(500)
submitted_by      UUID REFERENCES users(id)
assigned_to       UUID REFERENCES users(id)
created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

### approval_workflows
```sql
id                UUID PRIMARY KEY DEFAULT gen_random_uuid()
invoice_id        UUID REFERENCES invoices(id) ON DELETE CASCADE
approver_id       UUID REFERENCES users(id)
step_number       INTEGER NOT NULL
action            workflow_action NOT NULL
timestamp         TIMESTAMP DEFAULT CURRENT_TIMESTAMP
notes             TEXT
ip_address        INET
user_agent        TEXT
```

### purchase_orders
```sql
id                UUID PRIMARY KEY DEFAULT gen_random_uuid()
po_number         VARCHAR(100) UNIQUE NOT NULL
vendor_id         UUID REFERENCES vendors(id)
amount            DECIMAL(12,2) NOT NULL
department        VARCHAR(100)
requestor_id      UUID REFERENCES users(id)
status            po_status DEFAULT 'open'
created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
```

## Enums
```sql
CREATE TYPE user_role AS ENUM ('admin', 'manager', 'user', 'viewer');
CREATE TYPE invoice_status AS ENUM ('pending', 'in_review', 'approved', 'rejected', 'paid', 'cancelled');
CREATE TYPE priority_level AS ENUM ('low', 'medium', 'high', 'urgent');
CREATE TYPE workflow_action AS ENUM ('submit', 'approve', 'reject', 'request_info', 'escalate');
CREATE TYPE po_status AS ENUM ('open', 'partially_received', 'closed', 'cancelled');
```

## Indexes
```sql
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_invoices_vendor ON invoices(vendor_id);
CREATE INDEX idx_invoices_due_date ON invoices(due_date);
CREATE INDEX idx_invoices_amount ON invoices(amount);
CREATE INDEX idx_approval_workflows_invoice ON approval_workflows(invoice_id);
CREATE INDEX idx_vendors_name ON vendors(name);
```
EOF

# Create API_SPECIFICATION.md
cat > docs/API_SPECIFICATION.md << 'EOF'
# API Specification

## Authentication Endpoints

### POST /api/auth/login
```json
Request:
{
  "email": "user@company.com",
  "password": "securePassword123"
}

Response:
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid",
      "email": "user@company.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "manager",
      "department": "Finance"
    },
    "token": "jwt_token_here",
    "refreshToken": "refresh_token_here"
  }
}
```

### POST /api/auth/refresh
```json
Request:
{
  "refreshToken": "refresh_token_here"
}

Response:
{
  "success": true,
  "data": {
    "token": "new_jwt_token",
    "refreshToken": "new_refresh_token"
  }
}
```

## Invoice Endpoints

### GET /api/invoices
```
Query Parameters:
- status: pending|in_review|approved|rejected (optional)
- vendor: vendor_id (optional)
- department: string (optional)
- priority: low|medium|high|urgent (optional)
- limit: number (default: 25, max: 100)
- offset: number (default: 0)
- sortBy: created_at|due_date|amount (default: created_at)
- sortOrder: asc|desc (default: desc)

Response:
{
  "success": true,
  "data": {
    "invoices": [...],
    "pagination": {
      "total": 150,
      "limit": 25,
      "offset": 0,
      "hasMore": true
    }
  }
}
```

### POST /api/invoices
```json
Request (multipart/form-data):
{
  "file": "invoice.pdf",
  "metadata": {
    "department": "Operations",
    "priority": "medium"
  }
}

Response:
{
  "success": true,
  "data": {
    "invoice": {
      "id": "uuid",
      "invoiceNumber": "INV-2024-001",
      "vendor": {...},
      "amount": 1247.50,
      "dueDate": "2024-07-15",
      "status": "pending",
      "confidenceScore": 97,
      "aiExtractedData": {...}
    }
  }
}
```

### PUT /api/invoices/:id/approve
```json
Request:
{
  "notes": "Approved for payment"
}

Response:
{
  "success": true,
  "data": {
    "invoice": {...},
    "workflow": {
      "action": "approve",
      "approver": {...},
      "timestamp": "2024-06-25T10:30:00Z"
    }
  }
}
```

## Error Responses
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": {
      "field": "amount",
      "message": "Amount must be greater than 0"
    }
  }
}
```
EOF

# Create UI_COMPONENTS.md
cat > docs/UI_COMPONENTS.md << 'EOF'
# UI Components Specification

## Layout Components

### AppLayout
```tsx
interface AppLayoutProps {
  children: React.ReactNode;
  title?: string;
}

Features:
- Responsive sidebar navigation
- Header with user profile and notifications
- Breadcrumb navigation
- Mobile-friendly hamburger menu
- Real-time notification badges
```

### InvoiceCard
```tsx
interface InvoiceCardProps {
  invoice: Invoice;
  onApprove: (id: string, notes?: string) => void;
  onReject: (id: string, reason: string, notes?: string) => void;
  onView: (id: string) => void;
  compact?: boolean;
}

Features:
- Vendor logo or initial avatar
- Priority indicator badge
- AI confidence score
- Amount highlighting with currency formatting
- Due date with urgency color coding
- One-click approve/reject buttons
- Expandable details section
- Mobile-responsive design
- Loading states for actions
- Success/error animations
```

### Dashboard Components

#### StatsCard
```tsx
interface StatsCardProps {
  title: string;
  value: string | number;
  change?: number;
  icon?: React.ReactNode;
  color?: 'blue' | 'green' | 'red' | 'yellow';
  loading?: boolean;
}

Features:
- Animated counters
- Trend indicators
- Icon support
- Color theming
- Loading states
- Responsive design
```

### Form Components

#### InvoiceUpload
```tsx
interface InvoiceUploadProps {
  onUpload: (files: File[], metadata: UploadMetadata) => void;
  maxFiles?: number;
  acceptedTypes?: string[];
  maxSize?: number;
}

Features:
- Drag and drop interface
- Multiple file support
- File type validation
- Size limit checking
- Preview thumbnails
- Progress indicators
- Error messaging
- Metadata form fields
```

## Design System
- **Colors**: Blue primary (#3498db), Green success (#27ae60), Red danger (#e74c3c)
- **Typography**: Inter font family, responsive sizing
- **Spacing**: 8px base unit system
- **Breakpoints**: Mobile (640px), Tablet (768px), Desktop (1024px)
- **Animations**: Smooth transitions (300ms ease-in-out)
EOF

# Create BUSINESS_RULES.md
cat > docs/BUSINESS_RULES.md << 'EOF'
# Business Rules

## Approval Workflow Rules

### Amount-Based Routing
- Amount ≤ $500: Department Manager approval required
- Amount $501-$5,000: Director approval required
- Amount $5,001-$25,000: VP approval required
- Amount > $25,000: CFO approval required

### Department-Specific Rules
- IT purchases > $1,000: CTO approval required
- Marketing expenses > $2,000: CMO approval required
- Consulting services: Department head + Finance approval
- Capital expenditures > $10,000: Executive team approval

### Vendor Validation Rules
- New vendors: Additional verification required
- Unapproved vendors: Auto-reject with notification
- High-risk vendors: Enhanced due diligence
- Vendor blacklist: Immediate rejection

### PO Matching Rules
- 3-way matching: PO + Invoice + Receipt required for >$1,000
- PO amount variance >10%: Flag for review
- Missing PO for amounts >$500: Require justification
- Closed PO: Reject new invoices

## AI Validation Rules

### Data Extraction Confidence
- Confidence ≥ 95%: Auto-process
- Confidence 85-94%: Flag for human review
- Confidence < 85%: Require manual data entry

### Anomaly Detection
- Duplicate invoice numbers: Flag and hold
- Unusual amount patterns: Flag for review
- Weekend/holiday submissions: Enhanced scrutiny
- Multiple invoices from same vendor: Check for duplicates

## Escalation Rules

### Time-Based Escalation
- No action in 24 hours: Notify approver
- No action in 48 hours: Escalate to manager
- No action in 72 hours: Escalate to executive
- Critical invoices: 4-hour escalation window

### Priority Escalation
- Urgent priority: Immediate notification
- High priority: 2-hour response window
- Medium priority: 24-hour response window
- Low priority: 48-hour response window
EOF

# Create INTEGRATION_REQUIREMENTS.md
cat > docs/INTEGRATION_REQUIREMENTS.md << 'EOF'
# Integration Requirements

## ERP System Integrations

### QuickBooks Online
```
Authentication: OAuth 2.0
Base URL: https://sandbox-quickbooks.api.intuit.com/v3

Required Endpoints:
- GET /companyinfo/{companyID} - Company information
- GET /vendors - Vendor list
- POST /vendor - Create vendor
- GET /items - Chart of accounts
- POST /bill - Create bill/invoice
- GET /preferences - Company preferences

Data Mapping:
- Invoice → Bill
- Vendor → Vendor
- Amount → TotalAmt
- Due Date → DueDate
- Invoice Number → DocNumber
```

### NetSuite Integration
```
Authentication: Token-based authentication
Base URL: https://{account}.suitetalk.api.netsuite.com/rest

Required Endpoints:
- /record/v1/vendor - Vendor management
- /record/v1/vendorbill - Invoice/bill creation
- /record/v1/account - Chart of accounts
- /record/v1/department - Department list

Data Synchronization:
- Real-time sync for approved invoices
- Batch sync for vendor updates
- Error handling and retry logic
- Conflict resolution strategies
```

## Email Integration

### Incoming Email Processing
```
Email Server: IMAP/POP3 or Office 365 Graph API
Monitored Address: invoices@company.com

Processing Rules:
- Extract PDF/image attachments
- Forward to OCR processing queue
- Parse email metadata for context
- Auto-classify by sender domain
- Handle bounced/failed emails

Supported Formats:
- PDF documents
- JPEG/PNG images
- TIFF files
- Email body text parsing
```

## Make.com Workflow Integration

### Document Processing Workflow
```
Trigger: File upload or email received
Steps:
1. Document validation and virus scanning
2. OCR processing via AWS Textract
3. Data extraction and validation
4. Vendor lookup and verification
5. PO matching (if applicable)
6. Automatic routing based on business rules
7. Database record creation
8. Notification dispatch

Error Handling:
- Retry logic for failed operations
- Dead letter queue for manual review
- Alert notifications for system admins
```

### Approval Workflow
```
Trigger: Invoice approval/rejection
Steps:
1. Update invoice status in database
2. Create approval workflow record
3. Send notifications to relevant parties
4. Update ERP system (if approved)
5. Generate audit trail entries
6. Schedule payment (if applicable)
7. Archive documents to long-term storage

Conditional Logic:
- Amount-based routing rules
- Department-specific workflows
- Escalation triggers
- Holiday/weekend handling
```
EOF

# Create SECURITY_SPECIFICATIONS.md
cat > docs/SECURITY_SPECIFICATIONS.md << 'EOF'
# Security Specifications

## Authentication & Authorization

### Multi-Factor Authentication (MFA)
```
Required for:
- Admin users
- Users with approval limits >$10,000
- External/remote access
- Sensitive operations

Supported Methods:
- SMS verification codes
- Email verification codes
- Authenticator apps (TOTP)
- Hardware security keys (FIDO2)
```

### Role-Based Access Control (RBAC)
```
Roles:
- Super Admin: Full system access
- Finance Admin: Finance module + user management
- Manager: Department approval + team oversight
- User: Invoice submission + assigned approvals
- Viewer: Read-only access to permitted data

Permissions:
- CREATE_INVOICE
- APPROVE_INVOICE
- REJECT_INVOICE
- MANAGE_VENDORS
- VIEW_ANALYTICS
- MANAGE_USERS
- SYSTEM_SETTINGS
```

## Data Protection

### Encryption Standards
```
At Rest:
- AES-256 encryption for database
- Encrypted file storage (S3/Azure)
- Key management via HSM/KMS
- Regular key rotation

In Transit:
- TLS 1.3 for all connections
- Certificate pinning for mobile apps
- End-to-end encryption for sensitive data
- VPN requirements for admin access
```

### PII Handling
```
Sensitive Data Types:
- Social Security Numbers
- Tax ID Numbers
- Bank Account Information
- Personal Addresses
- Phone Numbers

Protection Measures:
- Field-level encryption
- Data masking for non-authorized users
- Audit logging for access
- Automatic redaction in exports
- Secure data disposal
```

## API Security

### Rate Limiting
```
Limits per IP/User:
- Authentication: 10 requests/minute
- General API: 1000 requests/hour
- File uploads: 50 requests/hour
- Bulk operations: 10 requests/hour

Implementation:
- Redis-based rate limiting
- Sliding window algorithm
- Graduated penalties for violations
- Whitelist for trusted IPs
```

### Input Validation
```
Validation Rules:
- SQL injection prevention
- XSS protection
- File type restrictions
- Size limitations
- Schema validation for all inputs

Sanitization:
- HTML encoding
- Special character filtering
- File content scanning
- Malware detection
```
EOF

# Create TESTING_CRITERIA.md
cat > docs/TESTING_CRITERIA.md << 'EOF'
# Testing Criteria

## Functional Testing

### Unit Tests (>90% Coverage)
```
Frontend Components:
- Component rendering
- User interactions
- State management
- Error handling
- Accessibility compliance

Backend Services:
- Business logic validation
- Database operations
- API endpoints
- Authentication flows
- Integration services

Test Framework:
- Jest for JavaScript/TypeScript
- React Testing Library for UI
- Supertest for API testing
- Mock implementations for external services
```

### Integration Tests
```
API Integration:
- End-to-end request/response cycles
- Database transaction testing
- External service mocking
- Error scenario handling
- Authentication workflow validation

Database Integration:
- CRUD operations
- Transaction integrity
- Constraint validation
- Performance testing
- Migration testing
```

## Performance Testing

### Load Testing Requirements
```
Targets:
- 100 concurrent users
- 1000 invoices processed per hour
- <2 second page load times
- <30 second OCR processing
- 99.9% uptime SLA

Scenarios:
- Normal business operation
- Peak processing periods
- System stress testing
- Database performance
- File upload/download speed

Tools:
- Artillery.js for load testing
- Lighthouse for performance auditing
- Database query optimization
```

## Security Testing

### Vulnerability Assessment
```
OWASP Top 10 Testing:
- Injection attacks
- Broken authentication
- Sensitive data exposure
- XML external entities
- Broken access control
- Security misconfiguration
- Cross-site scripting
- Insecure deserialization
- Component vulnerabilities
- Insufficient logging

Tools:
- OWASP ZAP for security scanning
- Snyk for dependency vulnerabilities
- SonarQube for code analysis
```

## Compliance Testing

### SOC 2 Type II Requirements
```
Security Controls:
- Access control testing
- System monitoring validation
- Change management procedures
- Incident response protocols
- Vendor management processes

Availability Controls:
- System monitoring
- Capacity planning
- Backup and recovery
- Business continuity planning
```
EOF

# Create DEPLOYMENT_GUIDE.md
cat > docs/DEPLOYMENT_GUIDE.md << 'EOF'
# Deployment Guide

## Environment Setup

### Development Environment
```
Local Setup:
- Node.js 18+ with npm/yarn
- PostgreSQL 15+ database
- Redis server
- Docker Desktop
- Git with pre-commit hooks

IDE Configuration:
- ESLint and Prettier setup
- TypeScript configuration
- Debugging configuration
- Testing framework setup
```

### Production Environment
```
High Availability Setup:
- Multi-region deployment
- Auto-scaling groups
- Load balancers with health checks
- Database clustering/replication
- Redis clustering
- Backup and disaster recovery

Security Configuration:
- WAF rules implementation
- DDoS protection
- Network security groups
- VPN access for administration
- Certificate management
- Compliance monitoring
```

## CI/CD Pipeline

### GitHub Actions Workflow
```yaml
name: Invoice Manager CI/CD

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:15
        env:
          POSTGRES_PASSWORD: postgres
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
      redis:
        image: redis:7
        options: >-
          --health-cmd "redis-cli ping"
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Run linting
        run: npm run lint
      
      - name: Run type checking
        run: npm run type-check
      
      - name: Run unit tests
        run: npm run test:unit
        env:
          DATABASE_URL: postgresql://postgres:postgres@localhost:5432/test
          REDIS_URL: redis://localhost:6379
```

## Database Migrations

### Migration Management
```
Tool: Prisma Migrate or custom migration system

Workflow:
1. Create migration script
2. Test in development environment
3. Review and approve migration
4. Deploy to staging
5. Validate staging deployment
6. Deploy to production with downtime window
7. Verify production deployment

Rollback Strategy:
- Backward-compatible migrations preferred
- Rollback scripts for destructive changes
- Data backup before major migrations
- Zero-downtime migration techniques
```

## Monitoring and Alerting

### Application Monitoring
```
Metrics to Track:
- Response time percentiles (p50, p95, p99)
- Request rate and error rate
- Database query performance
- Memory and CPU utilization
- Active user sessions
- Invoice processing throughput

Tools:
- Application Performance Monitoring (APM)
- Custom metrics via CloudWatch/Azure Monitor
- Real-time dashboards
- Automated alerting
```

### Alerting Rules
```
Critical Alerts (Immediate Response):
- Application down (>5 minutes)
- Database connection failures
- Security breach detection
- Data corruption indicators
- Payment processing failures

Warning Alerts (24-hour Response):
- High error rates (>5%)
- Slow response times (>5 seconds)
- Queue backlog buildup
- Disk space warnings
- Unusual traffic patterns
```
EOF

echo "✅ All specification files created successfully!"
echo ""
echo "📁 Files created in docs/ folder:"
ls -la docs/
echo ""
echo "🚀 Ready to run Claude Code!"
echo "Run: claude-code --project 'invoice-manager' --specs './docs/*.md' --generate-full-stack"

