#!/bin/bash

# Invoice Manager Startup Script

echo "🚀 Starting Invoice Manager..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18+ and try again."
    exit 1
fi

# Check if PostgreSQL is running
if ! command -v psql &> /dev/null; then
    echo "⚠️  PostgreSQL CLI not found. Make sure PostgreSQL is installed and running."
    echo "   You can install it with: brew install postgresql (macOS) or apt-get install postgresql (Ubuntu)"
fi

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing root dependencies..."
    npm install
fi

if [ ! -d "backend/node_modules" ]; then
    echo "📦 Installing backend dependencies..."
    cd backend && npm install && cd ..
fi

if [ ! -d "frontend/node_modules" ]; then
    echo "📦 Installing frontend dependencies..."
    cd frontend && npm install && cd ..
fi

# Check if .env exists
if [ ! -f "backend/.env" ]; then
    echo "⚠️  No .env file found. Using default development settings."
    echo "   For production, copy .env.example to backend/.env and configure your settings."
fi

# Setup database
echo "🗄️  Setting up database..."
cd backend

# Generate Prisma client
npx prisma generate

# Run migrations
echo "🔄 Running database migrations..."
npx prisma migrate dev --name init

# Seed database
echo "🌱 Seeding database with sample data..."
npm run db:seed

cd ..

echo "✅ Setup complete!"
echo ""
echo "🎯 To start the development servers:"
echo "   npm run dev"
echo ""
echo "📊 Demo login credentials:"
echo "   Admin: admin@company.com / password123"
echo "   Manager: manager@company.com / password123"
echo "   User: user@company.com / password123"
echo ""
echo "🌐 Application URLs:"
echo "   Frontend: http://localhost:5173"
echo "   Backend API: http://localhost:3001"
echo "   Health Check: http://localhost:3001/health"