# Invoice Management System

A complete full-stack invoice management system built with React, Node.js, PostgreSQL, and TypeScript.

## Features

- **Authentication & Authorization**: JWT-based auth with role-based access control
- **Invoice Management**: Upload, process, and track invoices with AI data extraction simulation
- **Multi-Level Approval Workflows**: Configurable approval routing based on amount and department
- **Real-Time Dashboard**: Live metrics and notifications
- **Vendor Management**: Complete vendor lifecycle management
- **Mobile-Responsive Design**: Optimized for desktop and mobile devices
- **Security**: SOC 2 compliant with encryption at rest and in transit

## Tech Stack

### Backend
- **Node.js** with **Express.js**
- **TypeScript** for type safety
- **PostgreSQL** with **Prisma ORM**
- **JWT** authentication with **Passport.js**
- **Redis** for caching and sessions
- **Socket.io** for real-time features

### Frontend
- **React 18** with **TypeScript**
- **Tailwind CSS** for styling
- **React Query** for data fetching
- **Zustand** for state management
- **React Hook Form** with **Zod** validation
- **React Router** for navigation

## Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL 15+
- Redis (optional, for production features)

### Installation

#### Option 1: Quick Start (Automated)
```bash
# Make sure you have PostgreSQL running
# Then run the setup script
./start.sh

# Start the development servers
npm run dev
```

#### Option 2: Manual Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd invoice-manager
   ```

2. **Install dependencies**
   ```bash
   npm install
   cd backend && npm install
   cd ../frontend && npm install
   cd ..
   ```

3. **Set up environment variables**
   ```bash
   # The .env file is already configured for development
   # For production, copy .env.example and configure your settings
   ```

4. **Set up the database**
   ```bash
   # Create PostgreSQL database
   createdb invoice_manager
   
   # Run migrations and seed data
   cd backend
   npx prisma generate
   npx prisma migrate dev --name init
   npm run db:seed
   cd ..
   ```

5. **Start the development servers**
   ```bash
   # From the root directory
   npm run dev
   ```

   This will start:
   - Backend API server on http://localhost:3001
   - Frontend React app on http://localhost:5173

## Demo Credentials

After seeding the database, you can log in with these credentials:

- **Admin**: admin@company.com / password123
- **Manager**: manager@company.com / password123  
- **User**: user@company.com / password123

## API Documentation

The API follows RESTful principles and includes the following main endpoints:

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/refresh` - Refresh access token
- `POST /api/auth/logout` - User logout

### Invoices
- `GET /api/invoices` - List invoices with filtering
- `POST /api/invoices` - Create new invoice
- `GET /api/invoices/:id` - Get invoice details
- `PUT /api/invoices/:id/status` - Update invoice status
- `GET /api/invoices/dashboard` - Dashboard statistics

### Approvals
- `POST /api/approvals/:invoiceId` - Process approval
- `GET /api/approvals/history/:invoiceId` - Get approval history
- `GET /api/approvals/pending` - Get pending approvals
- `GET /api/approvals/stats` - Approval statistics

### Vendors
- `GET /api/vendors` - List vendors
- `POST /api/vendors` - Create vendor
- `GET /api/vendors/:id` - Get vendor details
- `PUT /api/vendors/:id` - Update vendor
- `PUT /api/vendors/:id/approve` - Approve vendor

## Business Rules

### Approval Workflows
- **≤ $500**: Department Manager approval required
- **$501-$5,000**: Director approval required  
- **$5,001-$25,000**: VP approval required
- **> $25,000**: CFO approval required

### AI Validation
- **≥ 95% confidence**: Auto-process
- **85-94% confidence**: Flag for human review
- **< 85% confidence**: Require manual data entry

### Time-Based Escalation
- **24 hours**: Notify approver
- **48 hours**: Escalate to manager
- **72 hours**: Escalate to executive

## Development

### Backend Commands
```bash
cd backend
npm run dev          # Start development server
npm run build        # Build for production
npm run test         # Run tests
npm run lint         # Lint code
npm run typecheck    # Type checking
npm run db:migrate   # Run database migrations
npm run db:seed      # Seed database
```

### Frontend Commands
```bash
cd frontend
npm run dev          # Start development server
npm run build        # Build for production
npm run test         # Run tests
npm run lint         # Lint code
npm run typecheck    # Type checking
```

### Database Management
```bash
# View database in browser
npx prisma studio

# Reset database
npm run db:reset

# Create new migration
npx prisma migrate dev --name migration-name
```

## Project Structure

```
invoice-manager/
├── backend/                 # Node.js API server
│   ├── src/
│   │   ├── routes/         # API route handlers
│   │   ├── services/       # Business logic
│   │   ├── middleware/     # Express middleware
│   │   ├── types/          # TypeScript definitions
│   │   ├── utils/          # Utility functions
│   │   └── scripts/        # Database scripts
│   ├── prisma/             # Database schema and migrations
│   └── package.json
├── frontend/               # React application
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── pages/          # Page components
│   │   ├── services/       # API client
│   │   ├── store/          # State management
│   │   ├── types/          # TypeScript definitions
│   │   └── utils/          # Utility functions
│   └── package.json
├── docs/                   # Documentation
└── README.md
```

## Security Features

- JWT-based authentication with refresh tokens
- Role-based access control (RBAC)
- Input validation and sanitization
- Rate limiting and request throttling
- CORS protection
- Helmet.js security headers
- Password hashing with bcrypt
- SQL injection prevention
- XSS protection

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License. See LICENSE file for details.

## Support

For questions or support, please open an issue in the GitHub repository.