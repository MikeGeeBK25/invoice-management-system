import express from 'express';
import { body, query, param, validationResult } from 'express-validator';
import { VendorService } from '@/services/vendorService';
import { authenticateToken, requireRole } from '@/middleware/auth';

const router = express.Router();

const validateCreateVendor = [
  body('name').notEmpty().withMessage('Vendor name is required'),
  body('email').optional().isEmail().withMessage('Valid email is required'),
  body('phone').optional().isMobilePhone('any').withMessage('Valid phone number is required'),
  body('taxId').optional().isLength({ min: 3 }).withMessage('Tax ID must be at least 3 characters'),
  body('paymentTerms').optional().isInt({ min: 1, max: 365 }).withMessage('Payment terms must be between 1 and 365 days'),
];

const validateVendorFilters = [
  query('isApproved').optional().isBoolean(),
  query('riskScore').optional().isInt({ min: 0, max: 100 }),
  query('limit').optional().isInt({ min: 1, max: 100 }),
  query('offset').optional().isInt({ min: 0 }),
  query('search').optional().isLength({ min: 1 }),
];

const validateRiskScore = [
  body('riskScore').isInt({ min: 0, max: 100 }).withMessage('Risk score must be between 0 and 100'),
];

router.use(authenticateToken);

router.get('/', validateVendorFilters, async (req: express.Request, res: express.Response) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Invalid query parameters',
          details: errors.array(),
        },
      });
      return;
    }

    const filters = {
      isApproved: req.query.isApproved ? req.query.isApproved === 'true' : undefined,
      riskScore: req.query.riskScore ? parseInt(req.query.riskScore as string) : undefined,
      limit: req.query.limit ? parseInt(req.query.limit as string) : undefined,
      offset: req.query.offset ? parseInt(req.query.offset as string) : undefined,
      search: req.query.search as string,
    };

    const result = await VendorService.getVendors(filters);

    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error('Get vendors route error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'An internal error occurred',
      },
    });
  }
});

router.get('/stats', async (req: express.Request, res: express.Response) => {
  try {
    const result = await VendorService.getVendorStats();

    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error('Get vendor stats route error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'An internal error occurred',
      },
    });
  }
});

router.get('/:id',
  param('id').isUUID().withMessage('Valid vendor ID is required'),
  async (req: express.Request, res: express.Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid vendor ID',
            details: errors.array(),
          },
        });
        return;
      }

      const result = await VendorService.getVendorById(req.params.id!);

      if (result.success) {
        res.json(result);
      } else {
        const statusCode = result.error.code === 'VENDOR_NOT_FOUND' ? 404 : 500;
        res.status(statusCode).json(result);
      }
    } catch (error) {
      console.error('Get vendor route error:', error);
      res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An internal error occurred',
        },
      });
    }
  }
);

router.post('/',
  requireRole(['admin', 'manager']),
  validateCreateVendor,
  async (req: express.Request, res: express.Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid input data',
            details: errors.array(),
          },
        });
        return;
      }

      const result = await VendorService.createVendor(req.body);

      if (result.success) {
        res.status(201).json(result);
      } else {
        res.status(500).json(result);
      }
    } catch (error) {
      console.error('Create vendor route error:', error);
      res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An internal error occurred',
        },
      });
    }
  }
);

router.put('/:id',
  requireRole(['admin', 'manager']),
  param('id').isUUID().withMessage('Valid vendor ID is required'),
  validateCreateVendor,
  async (req: express.Request, res: express.Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid input data',
            details: errors.array(),
          },
        });
        return;
      }

      const result = await VendorService.updateVendor(req.params.id!, req.body);

      if (result.success) {
        res.json(result);
      } else {
        res.status(500).json(result);
      }
    } catch (error) {
      console.error('Update vendor route error:', error);
      res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An internal error occurred',
        },
      });
    }
  }
);

router.put('/:id/approve',
  requireRole(['admin', 'manager']),
  param('id').isUUID().withMessage('Valid vendor ID is required'),
  async (req: express.Request, res: express.Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid vendor ID',
            details: errors.array(),
          },
        });
        return;
      }

      const result = await VendorService.approveVendor(req.params.id!);

      if (result.success) {
        res.json(result);
      } else {
        res.status(500).json(result);
      }
    } catch (error) {
      console.error('Approve vendor route error:', error);
      res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An internal error occurred',
        },
      });
    }
  }
);

router.put('/:id/risk-score',
  requireRole(['admin', 'manager']),
  param('id').isUUID().withMessage('Valid vendor ID is required'),
  validateRiskScore,
  async (req: express.Request, res: express.Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid input data',
            details: errors.array(),
          },
        });
        return;
      }

      const { riskScore } = req.body;
      const result = await VendorService.updateRiskScore(req.params.id!, riskScore);

      if (result.success) {
        res.json(result);
      } else {
        res.status(500).json(result);
      }
    } catch (error) {
      console.error('Update risk score route error:', error);
      res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An internal error occurred',
        },
      });
    }
  }
);

export default router;