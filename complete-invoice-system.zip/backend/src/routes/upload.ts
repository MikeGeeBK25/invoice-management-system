import express from 'express';
import { body, validationResult } from 'express-validator';
import path from 'path';
import fs from 'fs/promises';
import { UploadService, upload } from '@/services/uploadService';
import { InvoiceService } from '@/services/invoiceService';
import { authenticateToken, AuthenticatedRequest } from '@/middleware/auth';
import { CreateInvoiceRequest, UploadMetadata } from '@/types';

const router = express.Router();

const validateMetadata = [
  body('department').optional().isLength({ min: 1 }).withMessage('Department cannot be empty'),
  body('priority').optional().isIn(['low', 'medium', 'high', 'urgent']).withMessage('Invalid priority'),
  body('category').optional().isLength({ min: 1 }).withMessage('Category cannot be empty'),
];

router.use(authenticateToken);

// Upload files and extract data
router.post('/files',
  upload.array('files', 5),
  validateMetadata,
  async (req: express.Request, res: express.Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid metadata',
            details: errors.array(),
          },
        });
        return;
      }

      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        res.status(400).json({
          success: false,
          error: {
            code: 'NO_FILES',
            message: 'No files uploaded',
          },
        });
        return;
      }

      // Validate all files
      for (const file of files) {
        const validation = await UploadService.validateFile(file);
        if (!validation.valid) {
          // Clean up uploaded files on validation error
          for (const f of files) {
            await UploadService.deleteFile(f.path).catch(console.error);
          }
          
          res.status(400).json({
            success: false,
            error: {
              code: 'FILE_VALIDATION_ERROR',
              message: validation.error,
              details: { filename: file.originalname },
            },
          });
          return;
        }
      }

      const result = await UploadService.processUploadedFiles(files);

      if (result.success) {
        res.json(result);
      } else {
        // Clean up files on processing error
        for (const file of files) {
          await UploadService.deleteFile(file.path).catch(console.error);
        }
        res.status(500).json(result);
      }
    } catch (error) {
      console.error('Upload route error:', error);
      
      // Clean up files on error
      const files = req.files as Express.Multer.File[];
      if (files) {
        for (const file of files) {
          await UploadService.deleteFile(file.path).catch(console.error);
        }
      }

      res.status(500).json({
        success: false,
        error: {
          code: 'UPLOAD_ERROR',
          message: 'Failed to upload files',
        },
      });
    }
  }
);

// Create invoice from extracted data
router.post('/create-invoice',
  body('extractedData').notEmpty().withMessage('Extracted data is required'),
  body('vendorId').isUUID().withMessage('Valid vendor ID is required'),
  body('filename').notEmpty().withMessage('Filename is required'),
  async (req: express.Request, res: express.Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid input data',
            details: errors.array(),
          },
        });
        return;
      }

      const authReq = req as AuthenticatedRequest;
      const { extractedData, vendorId, filename, metadata = {} } = req.body;

      // Create invoice data from extracted information
      const invoiceData: CreateInvoiceRequest = {
        invoiceNumber: extractedData.invoiceNumber || `INV-${Date.now()}`,
        vendorId,
        amount: extractedData.amount || 0,
        taxAmount: extractedData.taxAmount || 0,
        invoiceDate: extractedData.invoiceDate || new Date().toISOString().split('T')[0],
        dueDate: extractedData.dueDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        description: extractedData.description || metadata.description,
        department: metadata.department,
        category: metadata.category,
        priority: metadata.priority || 'medium',
      };

      const result = await InvoiceService.createInvoice(
        invoiceData,
        authReq.user.id,
        extractedData
      );

      if (result.success) {
        // Update invoice with file reference
        const invoice = result.data.invoice;
        invoice.originalFileUrl = UploadService.getFileUrl(filename);
        
        res.status(201).json(result);
      } else {
        res.status(500).json(result);
      }
    } catch (error) {
      console.error('Create invoice from upload error:', error);
      res.status(500).json({
        success: false,
        error: {
          code: 'CREATE_INVOICE_ERROR',
          message: 'Failed to create invoice from uploaded data',
        },
      });
    }
  }
);

// Serve uploaded files
router.get('/:filename', async (req: express.Request, res: express.Response) => {
  try {
    const { filename } = req.params;
    const filePath = path.join(process.cwd(), 'uploads', filename);

    // Check if file exists
    try {
      await fs.access(filePath);
    } catch (error) {
      res.status(404).json({
        success: false,
        error: {
          code: 'FILE_NOT_FOUND',
          message: 'File not found',
        },
      });
      return;
    }

    // Set appropriate headers
    const ext = path.extname(filename).toLowerCase();
    const mimeTypes: { [key: string]: string } = {
      '.pdf': 'application/pdf',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
    };

    const mimeType = mimeTypes[ext] || 'application/octet-stream';
    res.setHeader('Content-Type', mimeType);
    res.setHeader('Cache-Control', 'public, max-age=31536000'); // Cache for 1 year

    // Send file
    res.sendFile(filePath);
  } catch (error) {
    console.error('File serve error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'FILE_SERVE_ERROR',
        message: 'Failed to serve file',
      },
    });
  }
});

// Delete uploaded file
router.delete('/:filename', async (req: express.Request, res: express.Response) => {
  try {
    const { filename } = req.params;
    const filePath = path.join(process.cwd(), 'uploads', filename);

    await UploadService.deleteFile(filePath);

    res.json({
      success: true,
      data: { message: 'File deleted successfully' },
    });
  } catch (error) {
    console.error('File delete error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'FILE_DELETE_ERROR',
        message: 'Failed to delete file',
      },
    });
  }
});

export default router;