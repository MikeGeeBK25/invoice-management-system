import express from 'express';
import { body, validationResult } from 'express-validator';
import { AuthService } from '@/services/authService';
import { LoginRequest } from '@/types';

const router = express.Router();

const validateLogin = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Valid email is required'),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters'),
];

const validateRefreshToken = [
  body('refreshToken')
    .notEmpty()
    .withMessage('Refresh token is required'),
];

router.post('/login', validateLogin, async (req: express.Request, res: express.Response) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: errors.array(),
        },
      });
      return;
    }

    const credentials: LoginRequest = req.body;
    const result = await AuthService.login(credentials);

    if (result.success) {
      res.json(result);
    } else {
      const statusCode = result.error.code === 'INVALID_CREDENTIALS' ? 401 : 500;
      res.status(statusCode).json(result);
    }
  } catch (error) {
    console.error('Login route error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'An internal error occurred',
      },
    });
  }
});

router.post('/refresh', validateRefreshToken, async (req: express.Request, res: express.Response) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: errors.array(),
        },
      });
      return;
    }

    const { refreshToken } = req.body;
    const result = await AuthService.refreshToken(refreshToken);

    if (result.success) {
      res.json(result);
    } else {
      const statusCode = result.error.code === 'INVALID_REFRESH_TOKEN' ? 401 : 500;
      res.status(statusCode).json(result);
    }
  } catch (error) {
    console.error('Refresh token route error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'An internal error occurred',
      },
    });
  }
});

router.post('/logout', validateRefreshToken, async (req: express.Request, res: express.Response) => {
  try {
    const { refreshToken } = req.body;
    const result = await AuthService.logout(refreshToken);

    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error('Logout route error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'An internal error occurred',
      },
    });
  }
});

export default router;