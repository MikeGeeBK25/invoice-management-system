import express from 'express';
import { body, query, param, validationResult } from 'express-validator';
import { InvoiceService } from '@/services/invoiceService';
import { authenticateToken, AuthenticatedRequest, requireRole } from '@/middleware/auth';
import { CreateInvoiceRequest, InvoiceFilters, InvoiceStatus, PriorityLevel } from '@/types';

const router = express.Router();

const validateCreateInvoice = [
  body('invoiceNumber').notEmpty().withMessage('Invoice number is required'),
  body('vendorId').isUUID().withMessage('Valid vendor ID is required'),
  body('amount').isFloat({ min: 0.01 }).withMessage('Amount must be greater than 0'),
  body('taxAmount').optional().isFloat({ min: 0 }).withMessage('Tax amount must be non-negative'),
  body('invoiceDate').isISO8601().withMessage('Valid invoice date is required'),
  body('dueDate').isISO8601().withMessage('Valid due date is required'),
  body('priority').optional().isIn(['low', 'medium', 'high', 'urgent']).withMessage('Invalid priority'),
];

const validateInvoiceFilters = [
  query('status').optional().isIn(['pending', 'in_review', 'approved', 'rejected', 'paid', 'cancelled']),
  query('vendor').optional().isUUID(),
  query('priority').optional().isIn(['low', 'medium', 'high', 'urgent']),
  query('limit').optional().isInt({ min: 1, max: 100 }),
  query('offset').optional().isInt({ min: 0 }),
  query('sortBy').optional().isIn(['created_at', 'due_date', 'amount']),
  query('sortOrder').optional().isIn(['asc', 'desc']),
];

router.use(authenticateToken);

router.get('/', validateInvoiceFilters, async (req: express.Request, res: express.Response) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Invalid query parameters',
          details: errors.array(),
        },
      });
      return;
    }

    const filters: InvoiceFilters = {
      status: req.query.status as InvoiceStatus,
      vendor: req.query.vendor as string,
      department: req.query.department as string,
      priority: req.query.priority as PriorityLevel,
      limit: req.query.limit ? parseInt(req.query.limit as string) : undefined,
      offset: req.query.offset ? parseInt(req.query.offset as string) : undefined,
      sortBy: req.query.sortBy as 'created_at' | 'due_date' | 'amount',
      sortOrder: req.query.sortOrder as 'asc' | 'desc',
    };

    const authReq = req as AuthenticatedRequest;
    const result = authReq.user.role === 'admin' || authReq.user.role === 'manager'
      ? await InvoiceService.getInvoices(filters)
      : await InvoiceService.getInvoicesByUser(authReq.user.id, filters);

    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error('Get invoices route error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'An internal error occurred',
      },
    });
  }
});

router.get('/dashboard', async (req: express.Request, res: express.Response) => {
  try {
    const authReq = req as AuthenticatedRequest;
    const department = authReq.user.role === 'admin' ? undefined : authReq.user.department;
    
    const result = await InvoiceService.getDashboardStats(authReq.user.id, department);

    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error('Dashboard route error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'An internal error occurred',
      },
    });
  }
});

router.get('/:id', 
  param('id').isUUID().withMessage('Valid invoice ID is required'),
  async (req: express.Request, res: express.Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid invoice ID',
            details: errors.array(),
          },
        });
        return;
      }

      const result = await InvoiceService.getInvoiceById(req.params.id!);

      if (result.success) {
        res.json(result);
      } else {
        const statusCode = result.error.code === 'INVOICE_NOT_FOUND' ? 404 : 500;
        res.status(statusCode).json(result);
      }
    } catch (error) {
      console.error('Get invoice route error:', error);
      res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An internal error occurred',
        },
      });
    }
  }
);

router.post('/', validateCreateInvoice, async (req: express.Request, res: express.Response) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: errors.array(),
        },
      });
      return;
    }

    const authReq = req as AuthenticatedRequest;
    const invoiceData: CreateInvoiceRequest = req.body;
    
    const result = await InvoiceService.createInvoice(
      invoiceData,
      authReq.user.id
    );

    if (result.success) {
      res.status(201).json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error('Create invoice route error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'An internal error occurred',
      },
    });
  }
});

router.put('/:id/status',
  requireRole(['admin', 'manager']),
  param('id').isUUID().withMessage('Valid invoice ID is required'),
  body('status').isIn(['pending', 'in_review', 'approved', 'rejected', 'paid', 'cancelled']),
  body('assignedTo').optional().isUUID(),
  async (req: express.Request, res: express.Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid input data',
            details: errors.array(),
          },
        });
        return;
      }

      const { status, assignedTo } = req.body;
      const result = await InvoiceService.updateInvoiceStatus(
        req.params.id!,
        status,
        assignedTo
      );

      if (result.success) {
        res.json(result);
      } else {
        res.status(500).json(result);
      }
    } catch (error) {
      console.error('Update invoice status route error:', error);
      res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An internal error occurred',
        },
      });
    }
  }
);

export default router;