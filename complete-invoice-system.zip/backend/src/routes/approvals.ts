import express from 'express';
import { body, param, validationResult } from 'express-validator';
import { ApprovalService } from '@/services/approvalService';
import { authenticateToken, AuthenticatedRequest } from '@/middleware/auth';
import { ApprovalRequest } from '@/types';

const router = express.Router();

const validateApproval = [
  body('action')
    .isIn(['approve', 'reject', 'request_info', 'escalate'])
    .withMessage('Invalid approval action'),
  body('notes')
    .optional()
    .isLength({ max: 1000 })
    .withMessage('Notes must be less than 1000 characters'),
];

router.use(authenticateToken);

router.post('/:invoiceId',
  param('invoiceId').isUUID().withMessage('Valid invoice ID is required'),
  validateApproval,
  async (req: express.Request, res: express.Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid input data',
            details: errors.array(),
          },
        });
        return;
      }

      const authReq = req as AuthenticatedRequest;
      const { invoiceId } = req.params;
      const approval: ApprovalRequest = req.body;
      const ipAddress = req.ip || req.connection.remoteAddress;
      const userAgent = req.get('User-Agent');

      const result = await ApprovalService.processApproval(
        invoiceId,
        authReq.user.id,
        approval,
        ipAddress,
        userAgent
      );

      if (result.success) {
        res.json(result);
      } else {
        const statusCode = result.error.code === 'INVOICE_NOT_FOUND' ? 404 :
                          result.error.code === 'INSUFFICIENT_APPROVAL_AUTHORITY' ? 403 : 500;
        res.status(statusCode).json(result);
      }
    } catch (error) {
      console.error('Process approval route error:', error);
      res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An internal error occurred',
        },
      });
    }
  }
);

router.get('/history/:invoiceId',
  param('invoiceId').isUUID().withMessage('Valid invoice ID is required'),
  async (req: express.Request, res: express.Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid invoice ID',
            details: errors.array(),
          },
        });
        return;
      }

      const result = await ApprovalService.getApprovalHistory(req.params.invoiceId!);

      if (result.success) {
        res.json(result);
      } else {
        res.status(500).json(result);
      }
    } catch (error) {
      console.error('Get approval history route error:', error);
      res.status(500).json({
        success: false,
        error: {
          code: 'INTERNAL_ERROR',
          message: 'An internal error occurred',
        },
      });
    }
  }
);

router.get('/pending', async (req: express.Request, res: express.Response) => {
  try {
    const authReq = req as AuthenticatedRequest;
    const result = await ApprovalService.getPendingApprovals(authReq.user.id);

    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error('Get pending approvals route error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'An internal error occurred',
      },
    });
  }
});

router.get('/stats', async (req: express.Request, res: express.Response) => {
  try {
    const authReq = req as AuthenticatedRequest;
    const result = await ApprovalService.getApprovalStats(authReq.user.id);

    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error('Get approval stats route error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'An internal error occurred',
      },
    });
  }
});

export default router;