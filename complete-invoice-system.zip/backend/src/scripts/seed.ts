import { PrismaClient } from '@prisma/client';
import { AuthUtils } from '@/utils/auth';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  try {
    // Create admin user
    const adminPassword = await AuthUtils.hashPassword('password123');
    const admin = await prisma.user.upsert({
      where: { email: 'admin@company.com' },
      update: {},
      create: {
        email: 'admin@company.com',
        passwordHash: adminPassword,
        firstName: 'Admin',
        lastName: 'User',
        role: 'admin',
        department: 'IT',
        approvalLimit: 1000000,
        isActive: true,
      },
    });

    // Create manager user
    const managerPassword = await AuthUtils.hashPassword('password123');
    const manager = await prisma.user.upsert({
      where: { email: 'manager@company.com' },
      update: {},
      create: {
        email: 'manager@company.com',
        passwordHash: managerPassword,
        firstName: 'Finance',
        lastName: 'Manager',
        role: 'manager',
        department: 'Finance',
        approvalLimit: 50000,
        isActive: true,
      },
    });

    // Create regular user
    const userPassword = await AuthUtils.hashPassword('password123');
    const user = await prisma.user.upsert({
      where: { email: 'user@company.com' },
      update: {},
      create: {
        email: 'user@company.com',
        passwordHash: userPassword,
        firstName: 'John',
        lastName: 'Doe',
        role: 'user',
        department: 'Operations',
        approvalLimit: 5000,
        isActive: true,
      },
    });

    console.log('✅ Users created:', { admin: admin.id, manager: manager.id, user: user.id });

    // Create sample vendors
    const vendor1 = await prisma.vendor.upsert({
      where: { id: 'vendor1' },
      update: {},
      create: {
        id: 'vendor1',
        name: 'Acme Corporation',
        email: 'billing@acme.com',
        phone: '+1-555-123-4567',
        addressLine1: '123 Business Street',
        city: 'New York',
        state: 'NY',
        zipCode: '10001',
        country: 'USA',
        taxId: '12-3456789',
        paymentTerms: 30,
        isApproved: true,
        riskScore: 25,
      },
    });

    const vendor2 = await prisma.vendor.upsert({
      where: { id: 'vendor2' },
      update: {},
      create: {
        id: 'vendor2',
        name: 'Global Tech Solutions',
        email: 'invoices@globaltech.com',
        phone: '+1-555-987-6543',
        addressLine1: '456 Tech Avenue',
        city: 'San Francisco',
        state: 'CA',
        zipCode: '94105',
        country: 'USA',
        taxId: '98-7654321',
        paymentTerms: 45,
        isApproved: true,
        riskScore: 15,
      },
    });

    const vendor3 = await prisma.vendor.upsert({
      where: { id: 'vendor3' },
      update: {},
      create: {
        id: 'vendor3',
        name: 'Office Supplies Plus',
        email: 'accounts@officesupplies.com',
        phone: '+1-555-456-7890',
        addressLine1: '789 Supply Lane',
        city: 'Chicago',
        state: 'IL',
        zipCode: '60601',
        country: 'USA',
        taxId: '45-6789012',
        paymentTerms: 15,
        isApproved: false,
        riskScore: 60,
      },
    });

    console.log('✅ Vendors created:', { 
      vendor1: vendor1.id, 
      vendor2: vendor2.id, 
      vendor3: vendor3.id 
    });

    // Create sample purchase orders
    const po1 = await prisma.purchaseOrder.create({
      data: {
        poNumber: 'PO-2024-001',
        vendorId: vendor1.id,
        amount: 5000.00,
        department: 'IT',
        requestorId: admin.id,
        status: 'open',
      },
    });

    const po2 = await prisma.purchaseOrder.create({
      data: {
        poNumber: 'PO-2024-002',
        vendorId: vendor2.id,
        amount: 15000.00,
        department: 'Operations',
        requestorId: manager.id,
        status: 'open',
      },
    });

    console.log('✅ Purchase orders created:', { po1: po1.id, po2: po2.id });

    // Create sample invoices
    const invoice1 = await prisma.invoice.create({
      data: {
        invoiceNumber: 'INV-2024-001',
        vendorId: vendor1.id,
        amount: 4750.00,
        taxAmount: 380.00,
        totalAmount: 5130.00,
        currency: 'USD',
        invoiceDate: new Date('2024-06-01'),
        dueDate: new Date('2024-07-01'),
        description: 'Software licensing fees',
        poNumber: 'PO-2024-001',
        department: 'IT',
        category: 'Software',
        status: 'pending',
        priority: 'medium',
        confidenceScore: 96,
        submittedBy: user.id,
        assignedTo: manager.id,
        aiExtractedData: JSON.stringify({
          invoiceNumber: 'INV-2024-001',
          vendorName: 'Acme Corporation',
          amount: 4750.00,
          confidence: 96,
        }),
      },
    });

    const invoice2 = await prisma.invoice.create({
      data: {
        invoiceNumber: 'INV-2024-002',
        vendorId: vendor2.id,
        amount: 12500.00,
        taxAmount: 1000.00,
        totalAmount: 13500.00,
        currency: 'USD',
        invoiceDate: new Date('2024-06-05'),
        dueDate: new Date('2024-07-20'),
        description: 'Consulting services - Q2 2024',
        poNumber: 'PO-2024-002',
        department: 'Operations',
        category: 'Consulting',
        status: 'in_review',
        priority: 'high',
        confidenceScore: 89,
        submittedBy: user.id,
        assignedTo: admin.id,
        aiExtractedData: JSON.stringify({
          invoiceNumber: 'INV-2024-002',
          vendorName: 'Global Tech Solutions',
          amount: 12500.00,
          confidence: 89,
        }),
      },
    });

    const invoice3 = await prisma.invoice.create({
      data: {
        invoiceNumber: 'INV-2024-003',
        vendorId: vendor3.id,
        amount: 350.00,
        taxAmount: 28.00,
        totalAmount: 378.00,
        currency: 'USD',
        invoiceDate: new Date('2024-06-10'),
        dueDate: new Date('2024-06-25'),
        description: 'Office supplies and stationery',
        department: 'Operations',
        category: 'Office Supplies',
        status: 'approved',
        priority: 'low',
        confidenceScore: 98,
        submittedBy: user.id,
        aiExtractedData: JSON.stringify({
          invoiceNumber: 'INV-2024-003',
          vendorName: 'Office Supplies Plus',
          amount: 350.00,
          confidence: 98,
        }),
      },
    });

    console.log('✅ Invoices created:', { 
      invoice1: invoice1.id, 
      invoice2: invoice2.id, 
      invoice3: invoice3.id 
    });

    // Create approval workflow entries
    await prisma.approvalWorkflow.create({
      data: {
        invoiceId: invoice2.id,
        approverId: manager.id,
        stepNumber: 1,
        action: 'approve',
        notes: 'Approved for further review',
        timestamp: new Date('2024-06-06T10:30:00Z'),
      },
    });

    await prisma.approvalWorkflow.create({
      data: {
        invoiceId: invoice3.id,
        approverId: manager.id,
        stepNumber: 1,
        action: 'approve',
        notes: 'Standard office supplies - approved',
        timestamp: new Date('2024-06-11T14:15:00Z'),
      },
    });

    console.log('✅ Approval workflows created');

    console.log('🎉 Database seeded successfully!');
    console.log('\n📝 Demo login credentials:');
    console.log('Admin: admin@company.com / password123');
    console.log('Manager: manager@company.com / password123');
    console.log('User: user@company.com / password123');

  } catch (error) {
    console.error('❌ Error seeding database:', error);
    throw error;
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });