import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { JWTPayload } from '@/types';

const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'fallback-refresh-secret';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '15m';
const JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || '7d';

export class AuthUtils {
  static async hashPassword(password: string): Promise<string> {
    const saltRounds = 12;
    return bcrypt.hash(password, saltRounds);
  }

  static async comparePassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  }

  static generateToken(payload: JWTPayload): string {
    return jwt.sign(payload, JWT_SECRET, {
      expiresIn: JWT_EXPIRES_IN,
      issuer: 'invoice-manager',
      audience: 'invoice-manager-users',
    } as jwt.SignOptions);
  }

  static generateRefreshToken(payload: JWTPayload): string {
    return jwt.sign(payload, JWT_REFRESH_SECRET, {
      expiresIn: JWT_REFRESH_EXPIRES_IN,
      issuer: 'invoice-manager',
      audience: 'invoice-manager-users',
    } as jwt.SignOptions);
  }

  static verifyToken(token: string): JWTPayload {
    return jwt.verify(token, JWT_SECRET, {
      issuer: 'invoice-manager',
      audience: 'invoice-manager-users',
    }) as JWTPayload;
  }

  static verifyRefreshToken(token: string): JWTPayload {
    return jwt.verify(token, JWT_REFRESH_SECRET, {
      issuer: 'invoice-manager',
      audience: 'invoice-manager-users',
    }) as JWTPayload;
  }

  static generateTokenPair(payload: JWTPayload) {
    return {
      token: this.generateToken(payload),
      refreshToken: this.generateRefreshToken(payload),
    };
  }

  static getTokenExpirationDate(): Date {
    const expiration = JWT_EXPIRES_IN;
    const now = new Date();
    
    if (expiration.endsWith('m')) {
      const minutes = parseInt(expiration.slice(0, -1));
      return new Date(now.getTime() + minutes * 60 * 1000);
    } else if (expiration.endsWith('h')) {
      const hours = parseInt(expiration.slice(0, -1));
      return new Date(now.getTime() + hours * 60 * 60 * 1000);
    } else if (expiration.endsWith('d')) {
      const days = parseInt(expiration.slice(0, -1));
      return new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
    }
    
    return new Date(now.getTime() + 15 * 60 * 1000);
  }

  static getRefreshTokenExpirationDate(): Date {
    const expiration = JWT_REFRESH_EXPIRES_IN;
    const now = new Date();
    
    if (expiration.endsWith('d')) {
      const days = parseInt(expiration.slice(0, -1));
      return new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
    }
    
    return new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  }
}