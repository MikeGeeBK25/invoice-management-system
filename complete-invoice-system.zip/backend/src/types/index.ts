// Define types as string literals since we're using SQLite
export type UserRole = 'admin' | 'manager' | 'user' | 'viewer';
export type InvoiceStatus = 'pending' | 'in_review' | 'approved' | 'rejected' | 'paid' | 'cancelled';
export type PriorityLevel = 'low' | 'medium' | 'high' | 'urgent';
export type WorkflowAction = 'submit' | 'approve' | 'reject' | 'request_info' | 'escalate';

export interface AuthUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  department?: string;
  approvalLimit: number;
}

export interface JWTPayload {
  userId: string;
  email: string;
  role: UserRole;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  success: boolean;
  data: {
    user: AuthUser;
    token: string;
    refreshToken: string;
  };
}

export interface CreateInvoiceRequest {
  invoiceNumber: string;
  vendorId: string;
  amount: number;
  taxAmount?: number;
  invoiceDate: string;
  dueDate: string;
  description?: string;
  poNumber?: string;
  department?: string;
  category?: string;
  priority?: PriorityLevel;
}

export interface InvoiceFilters {
  status?: InvoiceStatus;
  vendor?: string;
  department?: string;
  priority?: PriorityLevel;
  limit?: number;
  offset?: number;
  sortBy?: 'created_at' | 'due_date' | 'amount';
  sortOrder?: 'asc' | 'desc';
}

export interface ApprovalRequest {
  action: WorkflowAction;
  notes?: string;
}

export interface AIExtractedData {
  invoiceNumber?: string;
  vendorName?: string;
  amount?: number;
  taxAmount?: number;
  invoiceDate?: string;
  dueDate?: string;
  description?: string;
  confidence: number;
  extractedFields: Record<string, any>;
}

export interface UploadMetadata {
  department?: string;
  priority?: PriorityLevel;
  category?: string;
}

export interface ErrorResponse {
  success: false;
  error: {
    code: string;
    message: string;
    details?: any;
  };
}

export interface SuccessResponse<T = any> {
  success: true;
  data: T;
}

export type ApiResponse<T = any> = SuccessResponse<T> | ErrorResponse;