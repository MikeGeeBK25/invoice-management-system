import multer from 'multer';
import path from 'path';
import fs from 'fs/promises';
import { AIExtractedData, ApiResponse } from '@/types';

const UPLOAD_DIR = path.join(process.cwd(), 'uploads');
const MAX_FILE_SIZE = parseInt(process.env.MAX_FILE_SIZE || '10485760'); // 10MB
const ALLOWED_TYPES = (process.env.ALLOWED_FILE_TYPES || 'image/jpeg,image/png,application/pdf').split(',');

// Ensure upload directory exists
const ensureUploadDir = async () => {
  try {
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
  } catch (error) {
    console.error('Error creating upload directory:', error);
  }
};

ensureUploadDir();

const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    cb(null, UPLOAD_DIR);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const extension = path.extname(file.originalname);
    const name = path.basename(file.originalname, extension);
    cb(null, `${name}-${uniqueSuffix}${extension}`);
  },
});

const fileFilter = (req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  if (ALLOWED_TYPES.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error(`File type ${file.mimetype} not allowed. Allowed types: ${ALLOWED_TYPES.join(', ')}`));
  }
};

export const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: MAX_FILE_SIZE,
    files: 5, // Maximum 5 files per upload
  },
});

export class UploadService {
  // Simulate AI data extraction from uploaded files
  static async extractDataFromFile(filePath: string, originalName: string): Promise<AIExtractedData> {
    try {
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Simulate AI extraction based on file name patterns
      const invoiceNumber = this.extractInvoiceNumber(originalName);
      const amount = this.extractAmount(originalName);
      const vendorName = this.extractVendorName(originalName);
      const confidence = this.calculateConfidence(invoiceNumber, amount, vendorName);

      return {
        invoiceNumber,
        vendorName,
        amount,
        taxAmount: amount ? amount * 0.08 : undefined, // 8% tax simulation
        invoiceDate: new Date().toISOString().split('T')[0],
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days from now
        description: `Extracted from ${originalName}`,
        confidence,
        extractedFields: {
          originalFileName: originalName,
          fileSize: await this.getFileSize(filePath),
          extractedAt: new Date().toISOString(),
          processingMethod: 'AI_SIMULATION',
        },
      };
    } catch (error) {
      console.error('AI extraction error:', error);
      return {
        confidence: 0,
        extractedFields: {
          error: 'Failed to extract data',
          originalFileName: originalName,
        },
      };
    }
  }

  private static extractInvoiceNumber(fileName: string): string | undefined {
    // Look for patterns like INV-123, Invoice123, etc.
    const patterns = [
      /INV[-_]?(\d+)/i,
      /INVOICE[-_]?(\d+)/i,
      /(\d{4,})/,
    ];

    for (const pattern of patterns) {
      const match = fileName.match(pattern);
      if (match) {
        return `INV-${match[1]}`;
      }
    }

    // Generate a random invoice number if none found
    return `INV-${Date.now().toString().slice(-6)}`;
  }

  private static extractAmount(fileName: string): number | undefined {
    // Look for currency amounts in filename
    const patterns = [
      /\$(\d+(?:,\d{3})*(?:\.\d{2})?)/,
      /(\d+(?:,\d{3})*(?:\.\d{2})?)\$?/,
      /amount[-_]?(\d+(?:\.\d{2})?)/i,
    ];

    for (const pattern of patterns) {
      const match = fileName.match(pattern);
      if (match) {
        const amount = parseFloat(match[1].replace(/,/g, ''));
        if (amount > 0 && amount < 1000000) { // Reasonable range
          return amount;
        }
      }
    }

    // Generate a random amount if none found
    return Math.round((Math.random() * 5000 + 100) * 100) / 100;
  }

  private static extractVendorName(fileName: string): string | undefined {
    // Common vendor names in filename patterns
    const vendorPatterns = [
      /acme/i,
      /microsoft/i,
      /apple/i,
      /google/i,
      /amazon/i,
      /office/i,
      /supply/i,
      /tech/i,
      /global/i,
      /corp/i,
    ];

    for (const pattern of vendorPatterns) {
      if (pattern.test(fileName)) {
        const match = fileName.match(pattern);
        if (match) {
          return match[0].charAt(0).toUpperCase() + match[0].slice(1).toLowerCase() + ' Corporation';
        }
      }
    }

    return undefined;
  }

  private static calculateConfidence(
    invoiceNumber?: string,
    amount?: number,
    vendorName?: string
  ): number {
    let confidence = 60; // Base confidence

    if (invoiceNumber) confidence += 15;
    if (amount && amount > 0) confidence += 15;
    if (vendorName) confidence += 10;

    // Add some randomness to simulate real AI confidence
    confidence += Math.floor(Math.random() * 10) - 5;

    return Math.max(0, Math.min(100, confidence));
  }

  private static async getFileSize(filePath: string): Promise<number> {
    try {
      const stats = await fs.stat(filePath);
      return stats.size;
    } catch (error) {
      return 0;
    }
  }

  static async processUploadedFiles(files: Express.Multer.File[]): Promise<ApiResponse> {
    try {
      const results = [];

      for (const file of files) {
        const extractedData = await this.extractDataFromFile(file.path, file.originalname);
        
        results.push({
          filename: file.filename,
          originalName: file.originalname,
          size: file.size,
          mimetype: file.mimetype,
          path: file.path,
          extractedData,
        });
      }

      return {
        success: true,
        data: {
          files: results,
          totalFiles: files.length,
        },
      };
    } catch (error) {
      console.error('File processing error:', error);
      return {
        success: false,
        error: {
          code: 'FILE_PROCESSING_ERROR',
          message: 'Failed to process uploaded files',
        },
      };
    }
  }

  static async deleteFile(filePath: string): Promise<void> {
    try {
      await fs.unlink(filePath);
    } catch (error) {
      console.error('Error deleting file:', error);
    }
  }

  static getFileUrl(filename: string): string {
    return `/api/uploads/${filename}`;
  }

  static async validateFile(file: Express.Multer.File): Promise<{ valid: boolean; error?: string }> {
    // Check file size
    if (file.size > MAX_FILE_SIZE) {
      return {
        valid: false,
        error: `File size exceeds maximum allowed size of ${MAX_FILE_SIZE / 1024 / 1024}MB`,
      };
    }

    // Check file type
    if (!ALLOWED_TYPES.includes(file.mimetype)) {
      return {
        valid: false,
        error: `File type ${file.mimetype} not allowed. Allowed types: ${ALLOWED_TYPES.join(', ')}`,
      };
    }

    // Check if file exists and is readable
    try {
      await fs.access(file.path);
      return { valid: true };
    } catch (error) {
      return {
        valid: false,
        error: 'File is not accessible',
      };
    }
  }
}