import { PrismaClient } from '@prisma/client';
import { ApiResponse } from '@/types';

const prisma = new PrismaClient();

interface CreateVendorData {
  name: string;
  email?: string;
  phone?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country?: string;
  taxId?: string;
  paymentTerms?: number;
}

interface VendorFilters {
  isApproved?: boolean;
  riskScore?: number;
  limit?: number;
  offset?: number;
  search?: string;
}

export class VendorService {
  static async createVendor(data: CreateVendorData): Promise<ApiResponse> {
    try {
      const vendor = await prisma.vendor.create({
        data: {
          ...data,
          country: data.country || 'USA',
          paymentTerms: data.paymentTerms || 30,
        },
      });

      return {
        success: true,
        data: { vendor },
      };
    } catch (error) {
      console.error('Create vendor error:', error);
      return {
        success: false,
        error: {
          code: 'CREATE_VENDOR_ERROR',
          message: 'Failed to create vendor',
        },
      };
    }
  }

  static async getVendors(filters: VendorFilters = {}): Promise<ApiResponse> {
    try {
      const {
        isApproved,
        riskScore,
        limit = 25,
        offset = 0,
        search,
      } = filters;

      const where: any = {};
      
      if (isApproved !== undefined) where.isApproved = isApproved;
      if (riskScore !== undefined) where.riskScore = { lte: riskScore };
      if (search) {
        where.OR = [
          { name: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
          { taxId: { contains: search, mode: 'insensitive' } },
        ];
      }

      const [vendors, total] = await Promise.all([
        prisma.vendor.findMany({
          where,
          include: {
            _count: {
              select: {
                invoices: true,
                purchaseOrders: true,
              },
            },
          },
          orderBy: { name: 'asc' },
          take: Math.min(limit, 100),
          skip: offset,
        }),
        prisma.vendor.count({ where }),
      ]);

      return {
        success: true,
        data: {
          vendors,
          pagination: {
            total,
            limit,
            offset,
            hasMore: offset + limit < total,
          },
        },
      };
    } catch (error) {
      console.error('Get vendors error:', error);
      return {
        success: false,
        error: {
          code: 'GET_VENDORS_ERROR',
          message: 'Failed to retrieve vendors',
        },
      };
    }
  }

  static async getVendorById(id: string): Promise<ApiResponse> {
    try {
      const vendor = await prisma.vendor.findUnique({
        where: { id },
        include: {
          invoices: {
            orderBy: { createdAt: 'desc' },
            take: 10,
            select: {
              id: true,
              invoiceNumber: true,
              amount: true,
              totalAmount: true,
              status: true,
              dueDate: true,
              createdAt: true,
            },
          },
          purchaseOrders: {
            orderBy: { createdAt: 'desc' },
            take: 5,
            select: {
              id: true,
              poNumber: true,
              amount: true,
              status: true,
              createdAt: true,
            },
          },
          _count: {
            select: {
              invoices: true,
              purchaseOrders: true,
            },
          },
        },
      });

      if (!vendor) {
        return {
          success: false,
          error: {
            code: 'VENDOR_NOT_FOUND',
            message: 'Vendor not found',
          },
        };
      }

      return {
        success: true,
        data: { vendor },
      };
    } catch (error) {
      console.error('Get vendor error:', error);
      return {
        success: false,
        error: {
          code: 'GET_VENDOR_ERROR',
          message: 'Failed to retrieve vendor',
        },
      };
    }
  }

  static async updateVendor(id: string, data: Partial<CreateVendorData>): Promise<ApiResponse> {
    try {
      const vendor = await prisma.vendor.update({
        where: { id },
        data: {
          ...data,
          updatedAt: new Date(),
        },
      });

      return {
        success: true,
        data: { vendor },
      };
    } catch (error) {
      console.error('Update vendor error:', error);
      return {
        success: false,
        error: {
          code: 'UPDATE_VENDOR_ERROR',
          message: 'Failed to update vendor',
        },
      };
    }
  }

  static async approveVendor(id: string): Promise<ApiResponse> {
    try {
      const vendor = await prisma.vendor.update({
        where: { id },
        data: {
          isApproved: true,
          updatedAt: new Date(),
        },
      });

      return {
        success: true,
        data: { vendor },
      };
    } catch (error) {
      console.error('Approve vendor error:', error);
      return {
        success: false,
        error: {
          code: 'APPROVE_VENDOR_ERROR',
          message: 'Failed to approve vendor',
        },
      };
    }
  }

  static async updateRiskScore(id: string, riskScore: number): Promise<ApiResponse> {
    try {
      const vendor = await prisma.vendor.update({
        where: { id },
        data: {
          riskScore,
          updatedAt: new Date(),
        },
      });

      return {
        success: true,
        data: { vendor },
      };
    } catch (error) {
      console.error('Update risk score error:', error);
      return {
        success: false,
        error: {
          code: 'UPDATE_RISK_SCORE_ERROR',
          message: 'Failed to update vendor risk score',
        },
      };
    }
  }

  static async getVendorStats(): Promise<ApiResponse> {
    try {
      const [
        totalVendors,
        approvedVendors,
        highRiskVendors,
        recentVendors,
        topVendorsByInvoiceCount,
      ] = await Promise.all([
        prisma.vendor.count(),
        prisma.vendor.count({ where: { isApproved: true } }),
        prisma.vendor.count({ where: { riskScore: { gte: 70 } } }),
        prisma.vendor.count({
          where: {
            createdAt: {
              gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
            },
          },
        }),
        prisma.vendor.findMany({
          include: {
            _count: {
              select: { invoices: true },
            },
          },
          orderBy: {
            invoices: {
              _count: 'desc',
            },
          },
          take: 5,
        }),
      ]);

      return {
        success: true,
        data: {
          stats: {
            totalVendors,
            approvedVendors,
            highRiskVendors,
            recentVendors,
          },
          topVendors: topVendorsByInvoiceCount,
        },
      };
    } catch (error) {
      console.error('Get vendor stats error:', error);
      return {
        success: false,
        error: {
          code: 'VENDOR_STATS_ERROR',
          message: 'Failed to retrieve vendor statistics',
        },
      };
    }
  }
}