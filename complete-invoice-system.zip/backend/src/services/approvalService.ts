import { PrismaClient } from '@prisma/client';
import { ApprovalRequest, ApiResponse } from '@/types';

const prisma = new PrismaClient();

export class ApprovalService {
  static async processApproval(
    invoiceId: string,
    approverId: string,
    approval: ApprovalRequest,
    ipAddress?: string,
    userAgent?: string
  ): Promise<ApiResponse> {
    try {
      const invoice = await prisma.invoice.findUnique({
        where: { id: invoiceId },
        include: {
          vendor: true,
          approvalWorkflow: {
            orderBy: { timestamp: 'desc' },
            take: 1,
          },
        },
      });

      if (!invoice) {
        return {
          success: false,
          error: {
            code: 'INVOICE_NOT_FOUND',
            message: 'Invoice not found',
          },
        };
      }

      const approver = await prisma.user.findUnique({
        where: { id: approverId },
      });

      if (!approver) {
        return {
          success: false,
          error: {
            code: 'APPROVER_NOT_FOUND',
            message: 'Approver not found',
          },
        };
      }

      const hasApprovalAuthority = await this.checkApprovalAuthority(
        approver,
        Number(invoice.totalAmount),
        invoice.department || undefined
      );

      if (!hasApprovalAuthority) {
        return {
          success: false,
          error: {
            code: 'INSUFFICIENT_APPROVAL_AUTHORITY',
            message: 'Insufficient approval authority for this invoice amount',
          },
        };
      }

      const currentStep = invoice.approvalWorkflow.length + 1;
      let newStatus: string;

      switch (approval.action) {
        case 'approve':
          const requiresHigherApproval = await this.requiresHigherApproval(
            Number(invoice.totalAmount),
            approver.role,
            invoice.department || undefined
          );
          
          if (requiresHigherApproval) {
            newStatus = 'in_review';
            await this.assignToNextApprover(invoiceId, Number(invoice.totalAmount), invoice.department ?? undefined);
          } else {
            newStatus = 'approved';
          }
          break;
        case 'reject':
          newStatus = 'rejected';
          break;
        case 'request_info':
          newStatus = 'pending';
          break;
        case 'escalate':
          newStatus = 'in_review';
          await this.escalateToHigherAuthority(invoiceId, invoice.department ?? undefined);
          break;
        default:
          return {
            success: false,
            error: {
              code: 'INVALID_ACTION',
              message: 'Invalid approval action',
            },
          };
      }

      const [workflowEntry, updatedInvoice] = await Promise.all([
        prisma.approvalWorkflow.create({
          data: {
            invoiceId,
            approverId,
            stepNumber: currentStep,
            action: approval.action,
            notes: approval.notes,
            ipAddress,
            userAgent,
          },
          include: {
            approver: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
                role: true,
              },
            },
          },
        }),
        prisma.invoice.update({
          where: { id: invoiceId },
          data: { status: newStatus },
          include: {
            vendor: true,
            submitter: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
              },
            },
            assignee: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
              },
            },
          },
        }),
      ]);

      return {
        success: true,
        data: {
          invoice: updatedInvoice,
          workflow: workflowEntry,
        },
      };
    } catch (error) {
      console.error('Process approval error:', error);
      return {
        success: false,
        error: {
          code: 'APPROVAL_PROCESSING_ERROR',
          message: 'Failed to process approval',
        },
      };
    }
  }

  private static async checkApprovalAuthority(
    approver: any,
    amount: number,
    department?: string
  ): Promise<boolean> {
    if (approver.role === 'admin') return true;

    const approvalLimit = Number(approver.approvalLimit || 0);
    
    if (amount <= 500) {
      return approver.role === 'manager' || approver.role === 'admin';
    } else if (amount <= 5000) {
      return approvalLimit >= amount || approver.role === 'admin';
    } else if (amount <= 25000) {
      return (approver.role === 'manager' && approvalLimit >= amount) || approver.role === 'admin';
    } else {
      return approver.role === 'admin';
    }
  }

  private static async requiresHigherApproval(
    amount: number,
    approverRole: string,
    department?: string
  ): Promise<boolean> {
    if (approverRole === 'admin') return false;

    if (amount > 25000) {
      return approverRole !== 'admin';
    } else if (amount > 5000) {
      return approverRole === 'user' || approverRole === 'viewer';
    } else if (amount > 500) {
      return approverRole === 'user' || approverRole === 'viewer';
    }

    return false;
  }

  private static async assignToNextApprover(
    invoiceId: string,
    amount: number,
    department?: string
  ): Promise<void> {
    try {
      let nextApprover;

      if (amount > 25000) {
        nextApprover = await prisma.user.findFirst({
          where: {
            role: 'admin',
            isActive: true,
          },
        });
      } else if (amount > 5000) {
        nextApprover = await prisma.user.findFirst({
          where: {
            role: { in: ['admin', 'manager'] },
            department: department || undefined,
            approvalLimit: { gte: amount },
            isActive: true,
          },
          orderBy: { approvalLimit: 'asc' },
        });
      } else {
        nextApprover = await prisma.user.findFirst({
          where: {
            role: { in: ['admin', 'manager'] },
            department: department || undefined,
            isActive: true,
          },
        });
      }

      if (nextApprover) {
        await prisma.invoice.update({
          where: { id: invoiceId },
          data: { assignedTo: nextApprover.id },
        });
      }
    } catch (error) {
      console.error('Assign to next approver error:', error);
    }
  }

  private static async escalateToHigherAuthority(
    invoiceId: string,
    department?: string
  ): Promise<void> {
    try {
      const admin = await prisma.user.findFirst({
        where: {
          role: 'admin',
          isActive: true,
        },
      });

      if (admin) {
        await prisma.invoice.update({
          where: { id: invoiceId },
          data: { assignedTo: admin.id },
        });
      }
    } catch (error) {
      console.error('Escalate to higher authority error:', error);
    }
  }

  static async getApprovalHistory(invoiceId: string): Promise<ApiResponse> {
    try {
      const approvalHistory = await prisma.approvalWorkflow.findMany({
        where: { invoiceId },
        include: {
          approver: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              role: true,
            },
          },
        },
        orderBy: { timestamp: 'asc' },
      });

      return {
        success: true,
        data: { approvalHistory },
      };
    } catch (error) {
      console.error('Get approval history error:', error);
      return {
        success: false,
        error: {
          code: 'APPROVAL_HISTORY_ERROR',
          message: 'Failed to retrieve approval history',
        },
      };
    }
  }

  static async getPendingApprovals(userId: string): Promise<ApiResponse> {
    try {
      const pendingInvoices = await prisma.invoice.findMany({
        where: {
          OR: [
            { assignedTo: userId },
            {
              AND: [
                { assignedTo: null },
                { status: 'pending' },
              ],
            },
          ],
          status: { in: ['pending', 'in_review'] },
        },
        include: {
          vendor: true,
          submitter: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
            },
          },
        },
        orderBy: [
          { priority: 'desc' },
          { dueDate: 'asc' },
        ],
      });

      return {
        success: true,
        data: { pendingInvoices },
      };
    } catch (error) {
      console.error('Get pending approvals error:', error);
      return {
        success: false,
        error: {
          code: 'PENDING_APPROVALS_ERROR',
          message: 'Failed to retrieve pending approvals',
        },
      };
    }
  }

  static async getApprovalStats(userId: string): Promise<ApiResponse> {
    try {
      const [totalApprovals, monthlyApprovals, averageApprovalTime] = await Promise.all([
        prisma.approvalWorkflow.count({
          where: { approverId: userId },
        }),
        prisma.approvalWorkflow.count({
          where: {
            approverId: userId,
            timestamp: {
              gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
            },
          },
        }),
        prisma.approvalWorkflow.findMany({
          where: {
            approverId: userId,
            action: { in: ['approve', 'reject'] },
          },
          include: {
            invoice: {
              select: {
                createdAt: true,
              },
            },
          },
          take: 100,
          orderBy: { timestamp: 'desc' },
        }),
      ]);

      const avgTime = averageApprovalTime.reduce((acc, approval) => {
        const timeDiff = approval.timestamp.getTime() - approval.invoice.createdAt.getTime();
        return acc + timeDiff;
      }, 0) / (averageApprovalTime.length || 1);

      return {
        success: true,
        data: {
          totalApprovals,
          monthlyApprovals,
          averageApprovalTimeHours: Math.round(avgTime / (1000 * 60 * 60) * 100) / 100,
        },
      };
    } catch (error) {
      console.error('Get approval stats error:', error);
      return {
        success: false,
        error: {
          code: 'APPROVAL_STATS_ERROR',
          message: 'Failed to retrieve approval statistics',
        },
      };
    }
  }
}