import { PrismaClient } from '@prisma/client';
import { CreateInvoiceRequest, InvoiceFilters, AIExtractedData, ApiResponse } from '@/types';

const prisma = new PrismaClient();

export class InvoiceService {
  static async createInvoice(
    data: CreateInvoiceRequest,
    submittedBy: string,
    aiData?: AIExtractedData
  ): Promise<ApiResponse> {
    try {
      const totalAmount = data.amount + (data.taxAmount || 0);

      const invoice = await prisma.invoice.create({
        data: {
          invoiceNumber: data.invoiceNumber,
          vendorId: data.vendorId,
          amount: data.amount,
          taxAmount: data.taxAmount || 0,
          totalAmount,
          invoiceDate: new Date(data.invoiceDate),
          dueDate: new Date(data.dueDate),
          description: data.description,
          poNumber: data.poNumber,
          department: data.department,
          category: data.category,
          priority: data.priority || 'medium',
          submittedBy,
          confidenceScore: aiData?.confidence || 0,
          aiExtractedData: aiData ? JSON.stringify(aiData) : null,
        },
        include: {
          vendor: true,
          submitter: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
            },
          },
        },
      });

      return {
        success: true,
        data: { invoice },
      };
    } catch (error) {
      console.error('Create invoice error:', error);
      return {
        success: false,
        error: {
          code: 'CREATE_INVOICE_ERROR',
          message: 'Failed to create invoice',
        },
      };
    }
  }

  static async getInvoices(filters: InvoiceFilters): Promise<ApiResponse> {
    try {
      const {
        status,
        vendor,
        department,
        priority,
        limit = 25,
        offset = 0,
        sortBy = 'created_at',
        sortOrder = 'desc',
      } = filters;

      const where: any = {};
      
      if (status) where.status = status;
      if (vendor) where.vendorId = vendor;
      if (department) where.department = department;
      if (priority) where.priority = priority;

      const [invoices, total] = await Promise.all([
        prisma.invoice.findMany({
          where,
          include: {
            vendor: true,
            submitter: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
              },
            },
            assignee: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
              },
            },
          },
          orderBy: { [sortBy]: sortOrder },
          take: Math.min(limit, 100),
          skip: offset,
        }),
        prisma.invoice.count({ where }),
      ]);

      return {
        success: true,
        data: {
          invoices,
          pagination: {
            total,
            limit,
            offset,
            hasMore: offset + limit < total,
          },
        },
      };
    } catch (error) {
      console.error('Get invoices error:', error);
      return {
        success: false,
        error: {
          code: 'GET_INVOICES_ERROR',
          message: 'Failed to retrieve invoices',
        },
      };
    }
  }

  static async getInvoiceById(id: string): Promise<ApiResponse> {
    try {
      const invoice = await prisma.invoice.findUnique({
        where: { id },
        include: {
          vendor: true,
          submitter: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              department: true,
            },
          },
          assignee: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
              department: true,
            },
          },
          approvalWorkflow: {
            include: {
              approver: {
                select: {
                  id: true,
                  firstName: true,
                  lastName: true,
                  email: true,
                },
              },
            },
            orderBy: { timestamp: 'asc' },
          },
        },
      });

      if (!invoice) {
        return {
          success: false,
          error: {
            code: 'INVOICE_NOT_FOUND',
            message: 'Invoice not found',
          },
        };
      }

      return {
        success: true,
        data: { invoice },
      };
    } catch (error) {
      console.error('Get invoice error:', error);
      return {
        success: false,
        error: {
          code: 'GET_INVOICE_ERROR',
          message: 'Failed to retrieve invoice',
        },
      };
    }
  }

  static async updateInvoiceStatus(
    id: string,
    status: string,
    assignedTo?: string
  ): Promise<ApiResponse> {
    try {
      const invoice = await prisma.invoice.update({
        where: { id },
        data: {
          status,
          assignedTo,
          updatedAt: new Date(),
        },
        include: {
          vendor: true,
          submitter: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
            },
          },
          assignee: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
            },
          },
        },
      });

      return {
        success: true,
        data: { invoice },
      };
    } catch (error) {
      console.error('Update invoice status error:', error);
      return {
        success: false,
        error: {
          code: 'UPDATE_INVOICE_ERROR',
          message: 'Failed to update invoice status',
        },
      };
    }
  }

  static async getDashboardStats(userId?: string, department?: string): Promise<ApiResponse> {
    try {
      const where: any = {};
      if (department) where.department = department;

      const [
        totalInvoices,
        pendingInvoices,
        approvedInvoices,
        rejectedInvoices,
        totalAmount,
        overdueInvoices,
      ] = await Promise.all([
        prisma.invoice.count({ where }),
        prisma.invoice.count({ where: { ...where, status: 'pending' } }),
        prisma.invoice.count({ where: { ...where, status: 'approved' } }),
        prisma.invoice.count({ where: { ...where, status: 'rejected' } }),
        prisma.invoice.aggregate({
          where,
          _sum: { totalAmount: true },
        }),
        prisma.invoice.count({
          where: {
            ...where,
            dueDate: { lt: new Date() },
            status: { in: ['pending', 'in_review', 'approved'] },
          },
        }),
      ]);

      const recentInvoices = await prisma.invoice.findMany({
        where,
        include: {
          vendor: { select: { name: true } },
          submitter: {
            select: { firstName: true, lastName: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: 5,
      });

      return {
        success: true,
        data: {
          stats: {
            totalInvoices,
            pendingInvoices,
            approvedInvoices,
            rejectedInvoices,
            totalAmount: Number(totalAmount._sum.totalAmount || 0),
            overdueInvoices,
          },
          recentInvoices,
        },
      };
    } catch (error) {
      console.error('Get dashboard stats error:', error);
      return {
        success: false,
        error: {
          code: 'DASHBOARD_STATS_ERROR',
          message: 'Failed to retrieve dashboard statistics',
        },
      };
    }
  }

  static async getInvoicesByUser(userId: string, filters: InvoiceFilters): Promise<ApiResponse> {
    try {
      const updatedFilters = { ...filters };
      const where: any = {
        OR: [
          { submittedBy: userId },
          { assignedTo: userId },
        ],
      };

      if (filters.status) where.status = filters.status;
      if (filters.department) where.department = filters.department;
      if (filters.priority) where.priority = filters.priority;

      const [invoices, total] = await Promise.all([
        prisma.invoice.findMany({
          where,
          include: {
            vendor: true,
            submitter: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
              },
            },
          },
          orderBy: { [filters.sortBy || 'created_at']: filters.sortOrder || 'desc' },
          take: Math.min(filters.limit || 25, 100),
          skip: filters.offset || 0,
        }),
        prisma.invoice.count({ where }),
      ]);

      return {
        success: true,
        data: {
          invoices,
          pagination: {
            total,
            limit: filters.limit || 25,
            offset: filters.offset || 0,
            hasMore: (filters.offset || 0) + (filters.limit || 25) < total,
          },
        },
      };
    } catch (error) {
      console.error('Get user invoices error:', error);
      return {
        success: false,
        error: {
          code: 'GET_USER_INVOICES_ERROR',
          message: 'Failed to retrieve user invoices',
        },
      };
    }
  }
}