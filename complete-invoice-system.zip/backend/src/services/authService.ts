import { PrismaClient } from '@prisma/client';
import { AuthUtils } from '@/utils/auth';
import { LoginRequest, LoginResponse, AuthUser, ApiResponse, UserRole } from '@/types';

const prisma = new PrismaClient();

export class AuthService {
  static async login(credentials: LoginRequest): Promise<ApiResponse<LoginResponse['data']>> {
    try {
      const { email, password } = credentials;

      const user = await prisma.user.findUnique({
        where: { email: email.toLowerCase() },
        select: {
          id: true,
          email: true,
          passwordHash: true,
          firstName: true,
          lastName: true,
          role: true,
          department: true,
          approvalLimit: true,
          isActive: true,
        },
      });

      if (!user || !user.isActive) {
        return {
          success: false,
          error: {
            code: 'INVALID_CREDENTIALS',
            message: 'Invalid email or password',
          },
        };
      }

      const isPasswordValid = await AuthUtils.comparePassword(password, user.passwordHash);
      if (!isPasswordValid) {
        return {
          success: false,
          error: {
            code: 'INVALID_CREDENTIALS',
            message: 'Invalid email or password',
          },
        };
      }

      const jwtPayload = {
        userId: user.id,
        email: user.email,
        role: user.role as UserRole,
      };

      const { token, refreshToken } = AuthUtils.generateTokenPair(jwtPayload);

      await prisma.refreshToken.create({
        data: {
          token: refreshToken,
          userId: user.id,
          expiresAt: AuthUtils.getRefreshTokenExpirationDate(),
        },
      });

      await prisma.user.update({
        where: { id: user.id },
        data: { lastLogin: new Date() },
      });

      const authUser: AuthUser = {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role as UserRole,
        department: user.department || undefined,
        approvalLimit: Number(user.approvalLimit || 0),
      };

      return {
        success: true,
        data: {
          user: authUser,
          token,
          refreshToken,
        },
      };
    } catch (error) {
      console.error('Login error:', error);
      return {
        success: false,
        error: {
          code: 'LOGIN_ERROR',
          message: 'An error occurred during login',
        },
      };
    }
  }

  static async refreshToken(refreshTokenValue: string): Promise<ApiResponse<{ token: string; refreshToken: string }>> {
    try {
      const payload = AuthUtils.verifyRefreshToken(refreshTokenValue);

      const storedToken = await prisma.refreshToken.findUnique({
        where: { token: refreshTokenValue },
        include: { user: true },
      });

      if (!storedToken || storedToken.expiresAt < new Date() || !storedToken.user.isActive) {
        if (storedToken) {
          await prisma.refreshToken.delete({
            where: { id: storedToken.id },
          });
        }
        return {
          success: false,
          error: {
            code: 'INVALID_REFRESH_TOKEN',
            message: 'Invalid or expired refresh token',
          },
        };
      }

      const jwtPayload = {
        userId: storedToken.user.id,
        email: storedToken.user.email,
        role: storedToken.user.role as UserRole,
      };

      const { token, refreshToken } = AuthUtils.generateTokenPair(jwtPayload);

      await prisma.refreshToken.update({
        where: { id: storedToken.id },
        data: {
          token: refreshToken,
          expiresAt: AuthUtils.getRefreshTokenExpirationDate(),
        },
      });

      return {
        success: true,
        data: {
          token,
          refreshToken,
        },
      };
    } catch (error) {
      console.error('Token refresh error:', error);
      return {
        success: false,
        error: {
          code: 'TOKEN_REFRESH_ERROR',
          message: 'An error occurred while refreshing token',
        },
      };
    }
  }

  static async logout(refreshTokenValue: string): Promise<ApiResponse<{ message: string }>> {
    try {
      await prisma.refreshToken.deleteMany({
        where: { token: refreshTokenValue },
      });

      return {
        success: true,
        data: { message: 'Logged out successfully' },
      };
    } catch (error) {
      console.error('Logout error:', error);
      return {
        success: false,
        error: {
          code: 'LOGOUT_ERROR',
          message: 'An error occurred during logout',
        },
      };
    }
  }

  static async cleanupExpiredTokens(): Promise<void> {
    try {
      await prisma.refreshToken.deleteMany({
        where: {
          expiresAt: {
            lt: new Date(),
          },
        },
      });
    } catch (error) {
      console.error('Token cleanup error:', error);
    }
  }
}