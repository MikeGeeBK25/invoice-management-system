import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';
import { AuthUtils } from '@/utils/auth';
import { AuthUser, UserRole } from '@/types';

const prisma = new PrismaClient();

export interface AuthenticatedRequest extends Request {
  user: AuthUser;
}

export const authenticateToken = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      res.status(401).json({
        success: false,
        error: {
          code: 'MISSING_TOKEN',
          message: 'Access token is required',
        },
      });
      return;
    }

    const payload = AuthUtils.verifyToken(token);
    
    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        department: true,
        approvalLimit: true,
        isActive: true,
      },
    });

    if (!user || !user.isActive) {
      res.status(401).json({
        success: false,
        error: {
          code: 'INVALID_USER',
          message: 'User not found or inactive',
        },
      });
      return;
    }

    (req as AuthenticatedRequest).user = {
      ...user,
      role: user.role as UserRole,
      department: user.department || undefined,
      approvalLimit: Number(user.approvalLimit || 0),
    };

    next();
  } catch (error) {
    res.status(401).json({
      success: false,
      error: {
        code: 'INVALID_TOKEN',
        message: 'Invalid or expired token',
      },
    });
  }
};

export const requireRole = (roles: UserRole[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const authReq = req as AuthenticatedRequest;
    
    if (!authReq.user) {
      res.status(401).json({
        success: false,
        error: {
          code: 'UNAUTHENTICATED',
          message: 'Authentication required',
        },
      });
      return;
    }

    if (!roles.includes(authReq.user.role)) {
      res.status(403).json({
        success: false,
        error: {
          code: 'INSUFFICIENT_PERMISSIONS',
          message: 'Insufficient permissions for this action',
        },
      });
      return;
    }

    next();
  };
};

export const requireApprovalLimit = (amount: number) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const authReq = req as AuthenticatedRequest;
    
    if (!authReq.user) {
      res.status(401).json({
        success: false,
        error: {
          code: 'UNAUTHENTICATED',
          message: 'Authentication required',
        },
      });
      return;
    }

    if (authReq.user.approvalLimit < amount && authReq.user.role !== 'admin') {
      res.status(403).json({
        success: false,
        error: {
          code: 'APPROVAL_LIMIT_EXCEEDED',
          message: `Approval limit exceeded. Required: $${amount}, Available: $${authReq.user.approvalLimit}`,
        },
      });
      return;
    }

    next();
  };
};