import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FileUpload } from '@/components/upload/FileUpload';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { vendorService, uploadService } from '@/services/api';
import { 
  FileText, 
  Eye, 
  CheckCircle, 
  AlertTriangle,
  Building2,
  DollarSign,
  Calendar,
} from 'lucide-react';
import toast from 'react-hot-toast';

interface UploadMetadata {
  department?: string;
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  category?: string;
}

interface ExtractedData {
  invoiceNumber?: string;
  vendorName?: string;
  amount?: number;
  taxAmount?: number;
  invoiceDate?: string;
  dueDate?: string;
  description?: string;
  confidence: number;
  extractedFields?: any;
}

interface ProcessedFile {
  filename: string;
  originalName: string;
  size: number;
  mimetype: string;
  extractedData: ExtractedData;
}

export const Upload: React.FC = () => {
  const [metadata, setMetadata] = useState<UploadMetadata>({
    department: '',
    priority: 'medium',
    category: '',
  });
  const [processedFiles, setProcessedFiles] = useState<ProcessedFile[]>([]);
  const [selectedVendors, setSelectedVendors] = useState<{ [key: string]: string }>({});

  const { data: vendorsData } = useQuery({
    queryKey: ['vendors'],
    queryFn: () => vendorService.getVendors({ isApproved: true }),
  });

  const vendors = vendorsData?.data?.data || [];

  const handleUpload = async (files: File[], uploadMetadata: UploadMetadata) => {
    try {
      const formData = new FormData();
      
      // Add files
      files.forEach(file => {
        formData.append('files', file);
      });

      // Add metadata
      Object.entries(uploadMetadata).forEach(([key, value]) => {
        if (value) {
          formData.append(key, value);
        }
      });

      const response = await uploadService.uploadFiles(formData);
      
      if (response.success && response.data) {
        setProcessedFiles(response.data.files);
        toast.success(`Successfully processed ${response.data.totalFiles} files`);
      } else {
        throw new Error(response.error?.message || 'Upload failed');
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload files');
      throw error;
    }
  };

  const handleCreateInvoice = async (file: ProcessedFile) => {
    try {
      const vendorId = selectedVendors[file.filename];
      if (!vendorId) {
        toast.error('Please select a vendor before creating the invoice');
        return;
      }

      const response = await uploadService.createInvoiceFromUpload({
        extractedData: file.extractedData,
        vendorId,
        filename: file.filename,
        metadata,
      });

      if (response.success) {
        toast.success('Invoice created successfully!');
        // Remove the processed file from the list
        setProcessedFiles(prev => prev.filter(f => f.filename !== file.filename));
      } else {
        throw new Error(response.error?.message || 'Failed to create invoice');
      }
    } catch (error) {
      console.error('Create invoice error:', error);
      toast.error('Failed to create invoice');
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 95) return 'text-green-600 bg-green-100';
    if (confidence >= 85) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getConfidenceIcon = (confidence: number) => {
    if (confidence >= 95) return <CheckCircle className="w-4 h-4" />;
    return <AlertTriangle className="w-4 h-4" />;
  };

  const formatAmount = (amount?: number) => {
    if (!amount) return 'Not detected';
    return `$${amount.toLocaleString()}`;
  };

  const findVendorByName = (vendorName?: string): any | undefined => {
    if (!vendorName) return undefined;
    return vendors.find((vendor: any) => 
      vendor.name.toLowerCase().includes(vendorName.toLowerCase()) ||
      vendorName.toLowerCase().includes(vendor.name.toLowerCase())
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Upload Invoices</h1>
        <p className="mt-2 text-gray-600">
          Upload invoice files for AI-powered data extraction and processing.
        </p>
      </div>

      {/* File Upload Component */}
      <FileUpload
        onUpload={handleUpload}
        metadata={metadata}
        onMetadataChange={setMetadata}
        maxFiles={5}
        acceptedTypes={['image/jpeg', 'image/png', 'application/pdf']}
        maxSize={10 * 1024 * 1024} // 10MB
      />

      {/* Processed Files */}
      {processedFiles.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="w-5 h-5" />
              <span>Extracted Data ({processedFiles.length} files)</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {processedFiles.map((file) => {
                const suggestedVendor = findVendorByName(file.extractedData.vendorName);
                return (
                  <div
                    key={file.filename}
                    className="border border-gray-200 rounded-lg p-6 space-y-4"
                  >
                    {/* File Header */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <FileText className="w-6 h-6 text-gray-400" />
                        <div>
                          <h3 className="font-medium text-gray-900">{file.originalName}</h3>
                          <p className="text-sm text-gray-500">
                            {(file.size / 1024).toFixed(1)} KB • {file.mimetype}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {getConfidenceIcon(file.extractedData.confidence)}
                        <Badge className={getConfidenceColor(file.extractedData.confidence)}>
                          {file.extractedData.confidence}% confidence
                        </Badge>
                      </div>
                    </div>

                    {/* Extracted Data */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-gray-500">Invoice Number</label>
                        <p className="font-medium">{file.extractedData.invoiceNumber || 'Not detected'}</p>
                      </div>
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-gray-500">Amount</label>
                        <div className="flex items-center space-x-1">
                          <DollarSign className="w-4 h-4 text-gray-400" />
                          <p className="font-medium">{formatAmount(file.extractedData.amount)}</p>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-gray-500">Invoice Date</label>
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <p className="font-medium">
                            {file.extractedData.invoiceDate ? 
                              new Date(file.extractedData.invoiceDate).toLocaleDateString() : 
                              'Not detected'
                            }
                          </p>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <label className="text-sm font-medium text-gray-500">Detected Vendor</label>
                        <p className="font-medium">{file.extractedData.vendorName || 'Not detected'}</p>
                      </div>
                    </div>

                    {/* Vendor Selection */}
                    <div className="space-y-3">
                      <label className="block text-sm font-medium text-gray-700">
                        Select Vendor *
                      </label>
                      <div className="flex space-x-4">
                        <select
                          value={selectedVendors[file.filename] || ''}
                          onChange={(e) => setSelectedVendors(prev => ({
                            ...prev,
                            [file.filename]: e.target.value
                          }))}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                        >
                          <option value="">Select a vendor...</option>
                          {vendors.map((vendor: any) => (
                            <option key={vendor.id} value={vendor.id}>
                              {vendor.name} {suggestedVendor?.id === vendor.id && '(Suggested)'}
                            </option>
                          ))}
                        </select>
                        {suggestedVendor && (
                          <Button
                            variant="secondary"
                            onClick={() => setSelectedVendors(prev => ({
                              ...prev,
                              [file.filename]: suggestedVendor.id
                            }))}
                          >
                            Use Suggested
                          </Button>
                        )}
                      </div>
                      {suggestedVendor && (
                        <div className="flex items-center space-x-2 text-sm text-blue-600">
                          <Building2 className="w-4 h-4" />
                          <span>AI suggested: {suggestedVendor.name}</span>
                        </div>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                      <div className="flex space-x-2">
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => window.open(`/api/uploads/${file.filename}`, '_blank')}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          View File
                        </Button>
                      </div>
                      <Button
                        onClick={() => handleCreateInvoice(file)}
                        disabled={!selectedVendors[file.filename]}
                      >
                        Create Invoice
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Help Card */}
      <Card>
        <CardHeader>
          <CardTitle>Upload Tips</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm text-gray-600">
            <p>• <strong>Supported formats:</strong> PDF, JPEG, PNG</p>
            <p>• <strong>File size limit:</strong> 10MB per file</p>
            <p>• <strong>AI extraction:</strong> Works best with clear, high-quality images and PDFs</p>
            <p>• <strong>Vendor matching:</strong> AI will suggest vendors based on extracted data</p>
            <p>• <strong>Review extracted data:</strong> Always verify AI-extracted information before creating invoices</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};