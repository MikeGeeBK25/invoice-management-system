import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  CheckCircle, 
  XCircle, 
  MessageSquare, 
  Clock,
  AlertTriangle,
  Eye,
  Calendar,
  DollarSign
} from 'lucide-react';
import { approvalService } from '@/services/api';
import { Invoice, ApprovalRequest, ApprovalWorkflow } from '@/types';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { useAuthStore } from '@/store/auth';
import toast from 'react-hot-toast';

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-800',
  in_review: 'bg-blue-100 text-blue-800',
  approved: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800',
  paid: 'bg-purple-100 text-purple-800',
  cancelled: 'bg-gray-100 text-gray-800',
};

const priorityColors = {
  low: 'bg-gray-100 text-gray-800',
  medium: 'bg-blue-100 text-blue-800',
  high: 'bg-orange-100 text-orange-800',
  urgent: 'bg-red-100 text-red-800',
};

interface ApprovalModalProps {
  invoice: Invoice;
  isOpen: boolean;
  onClose: () => void;
  onApprove: (invoiceId: string, notes?: string) => void;
  onReject: (invoiceId: string, reason: string, notes?: string) => void;
}

const ApprovalModal: React.FC<ApprovalModalProps> = ({
  invoice,
  isOpen,
  onClose,
  onApprove,
  onReject,
}) => {
  const [action, setAction] = useState<'approve' | 'reject' | null>(null);
  const [notes, setNotes] = useState('');
  const [reason, setReason] = useState('');

  const { data: historyData } = useQuery({
    queryKey: ['approval-history', invoice.id],
    queryFn: () => approvalService.getApprovalHistory(invoice.id),
    enabled: isOpen,
  });

  const approvalHistory = historyData?.data?.approvalHistory || [];

  const handleSubmit = () => {
    if (action === 'approve') {
      onApprove(invoice.id, notes);
    } else if (action === 'reject' && reason) {
      onReject(invoice.id, reason, notes);
    }
    onClose();
    setAction(null);
    setNotes('');
    setReason('');
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-screen overflow-y-auto">
        <div className="p-6 border-b">
          <h2 className="text-xl font-semibold">
            Review Invoice - {invoice.invoiceNumber}
          </h2>
        </div>

        <div className="p-6 space-y-6">
          {/* Invoice Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-medium text-lg">Invoice Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Vendor:</span>
                  <span className="font-medium">{invoice.vendor.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Amount:</span>
                  <span className="font-medium">{formatCurrency(invoice.amount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tax:</span>
                  <span className="font-medium">{formatCurrency(invoice.taxAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total:</span>
                  <span className="font-bold text-lg">{formatCurrency(invoice.totalAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Due Date:</span>
                  <span className="font-medium">{formatDate(invoice.dueDate)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Department:</span>
                  <span className="font-medium">{invoice.department || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">PO Number:</span>
                  <span className="font-medium">{invoice.poNumber || 'N/A'}</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="font-medium text-lg">Processing Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Submitted by:</span>
                  <span className="font-medium">
                    {invoice.submitter.firstName} {invoice.submitter.lastName}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Priority:</span>
                  <Badge className={priorityColors[invoice.priority]}>
                    {invoice.priority}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">AI Confidence:</span>
                  <span className="font-medium">{invoice.confidenceScore}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Status:</span>
                  <Badge className={statusColors[invoice.status]}>
                    {invoice.status.replace('_', ' ')}
                  </Badge>
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          {invoice.description && (
            <div>
              <h3 className="font-medium text-lg mb-2">Description</h3>
              <p className="text-gray-700 bg-gray-50 p-3 rounded-md">
                {invoice.description}
              </p>
            </div>
          )}

          {/* Approval History */}
          {approvalHistory.length > 0 && (
            <div>
              <h3 className="font-medium text-lg mb-4">Approval History</h3>
              <div className="space-y-3">
                {approvalHistory.map((approval: ApprovalWorkflow) => (
                  <div key={approval.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-md">
                    <div className="flex-shrink-0">
                      {approval.action === 'approve' && (
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      )}
                      {approval.action === 'reject' && (
                        <XCircle className="w-5 h-5 text-red-600" />
                      )}
                      {approval.action === 'request_info' && (
                        <MessageSquare className="w-5 h-5 text-blue-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">
                          {approval.approver.firstName} {approval.approver.lastName}
                        </span>
                        <span className="text-sm text-gray-500">
                          {formatDate(approval.timestamp)}
                        </span>
                      </div>
                      <div className="text-sm text-gray-600">
                        {approval.action.replace('_', ' ')} - Step {approval.stepNumber}
                      </div>
                      {approval.notes && (
                        <div className="text-sm text-gray-700 mt-1">
                          {approval.notes}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Approval Actions */}
          <div className="border-t pt-6">
            <h3 className="font-medium text-lg mb-4">Take Action</h3>
            
            <div className="space-y-4">
              <div className="flex space-x-4">
                <Button
                  onClick={() => setAction('approve')}
                  className={`flex-1 ${action === 'approve' ? 'bg-green-600 hover:bg-green-700' : 'bg-green-600 hover:bg-green-700'}`}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Approve
                </Button>
                <Button
                  onClick={() => setAction('reject')}
                  variant="outline"
                  className={`flex-1 border-red-300 text-red-700 hover:bg-red-50 ${action === 'reject' ? 'bg-red-50' : ''}`}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Reject
                </Button>
              </div>

              {action === 'reject' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Rejection Reason *
                  </label>
                  <select
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    required
                  >
                    <option value="">Select a reason</option>
                    <option value="insufficient_documentation">Insufficient Documentation</option>
                    <option value="invalid_amount">Invalid Amount</option>
                    <option value="duplicate_invoice">Duplicate Invoice</option>
                    <option value="vendor_not_approved">Vendor Not Approved</option>
                    <option value="missing_po">Missing Purchase Order</option>
                    <option value="budget_exceeded">Budget Exceeded</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              )}

              {action && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Notes {action === 'reject' ? '(Optional)' : ''}
                  </label>
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={3}
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="Add any additional notes..."
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="p-6 border-t bg-gray-50 flex justify-end space-x-3">
          <Button
            variant="outline"
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!action || (action === 'reject' && !reason)}
            className={action === 'approve' ? 'bg-green-600 hover:bg-green-700' : action === 'reject' ? 'bg-red-600 hover:bg-red-700' : ''}
          >
            {action === 'approve' ? 'Approve Invoice' : action === 'reject' ? 'Reject Invoice' : 'Select Action'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export const Approvals: React.FC = () => {
  const { user } = useAuthStore();
  const queryClient = useQueryClient();
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  const { data: pendingData, isLoading } = useQuery({
    queryKey: ['pending-approvals'],
    queryFn: () => approvalService.getPendingApprovals(),
  });

  const { data: statsData } = useQuery({
    queryKey: ['approval-stats'],
    queryFn: () => approvalService.getApprovalStats(),
    enabled: user?.role === 'manager' || user?.role === 'admin',
  });

  const approvalMutation = useMutation({
    mutationFn: ({ invoiceId, approval }: { invoiceId: string; approval: ApprovalRequest }) =>
      approvalService.processApproval(invoiceId, approval),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-approvals'] });
      queryClient.invalidateQueries({ queryKey: ['approval-stats'] });
      toast.success('Approval processed successfully');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to process approval');
    },
  });

  const handleApprove = (invoiceId: string, notes?: string) => {
    approvalMutation.mutate({
      invoiceId,
      approval: { action: 'approve', notes },
    });
  };

  const handleReject = (invoiceId: string, reason: string, notes?: string) => {
    approvalMutation.mutate({
      invoiceId,
      approval: { action: 'reject', notes: notes || reason },
    });
  };

  const pendingInvoices = pendingData?.data?.pendingInvoices || [];
  const stats = statsData?.data;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const getUrgencyLevel = (invoice: Invoice) => {
    const dueDate = new Date(invoice.dueDate);
    const now = new Date();
    const daysDiff = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysDiff < 0) return { level: 'overdue', color: 'text-red-600', icon: AlertTriangle };
    if (daysDiff <= 3) return { level: 'urgent', color: 'text-orange-600', icon: Clock };
    if (daysDiff <= 7) return { level: 'soon', color: 'text-yellow-600', icon: Calendar };
    return { level: 'normal', color: 'text-gray-600', icon: Calendar };
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Approvals</h1>
          <p className="mt-2 text-gray-600">
            Review and approve pending invoices
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Approvals</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalApprovals}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">This Month</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.monthlyApprovals}</p>
                </div>
                <Calendar className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg. Time</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.averageApprovalTimeHours.toFixed(1)}h</p>
                </div>
                <Clock className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Pending Approvals */}
      <Card>
        <CardHeader>
          <CardTitle>Pending Approvals ({pendingInvoices.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-2 text-gray-500">Loading pending approvals...</p>
            </div>
          ) : pendingInvoices.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <p className="text-gray-500">No pending approvals</p>
              <p className="text-sm text-gray-400">All caught up!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {pendingInvoices.map((invoice: Invoice) => {
                const urgency = getUrgencyLevel(invoice);
                const UrgencyIcon = urgency.icon;
                
                return (
                  <div
                    key={invoice.id}
                    className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3">
                          <div>
                            <div className="flex items-center space-x-2">
                              <h3 className="font-medium text-gray-900">
                                {invoice.invoiceNumber}
                              </h3>
                              <Badge className={priorityColors[invoice.priority]}>
                                {invoice.priority}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600">
                              {invoice.vendor.name} • {invoice.department}
                            </p>
                          </div>
                        </div>
                        
                        <div className="mt-2 flex items-center space-x-6 text-sm text-gray-600">
                          <div className="flex items-center space-x-1">
                            <DollarSign className="w-4 h-4" />
                            <span className="font-medium">{formatCurrency(invoice.totalAmount)}</span>
                          </div>
                          <div className={`flex items-center space-x-1 ${urgency.color}`}>
                            <UrgencyIcon className="w-4 h-4" />
                            <span>Due {formatDate(invoice.dueDate)}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <span>AI Confidence: {invoice.confidenceScore}%</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedInvoice(invoice)}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          Review
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleApprove(invoice.id)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Quick Approve
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Approval Modal */}
      {selectedInvoice && (
        <ApprovalModal
          invoice={selectedInvoice}
          isOpen={!!selectedInvoice}
          onClose={() => setSelectedInvoice(null)}
          onApprove={handleApprove}
          onReject={handleReject}
        />
      )}
    </div>
  );
};