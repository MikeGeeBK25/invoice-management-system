import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { StatsCard } from '@/components/dashboard/StatsCard';
import { InvoiceCard } from '@/components/invoices/InvoiceCard';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { invoiceService, approvalService } from '@/services/api';
import { useAuthStore } from '@/store/auth';
import {
  DollarSign,
  FileText,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Calendar,
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const { user } = useAuthStore();

  const { data: dashboardData, isLoading: isDashboardLoading } = useQuery({
    queryKey: ['dashboard'],
    queryFn: () => invoiceService.getDashboardStats(),
  });

  const { data: pendingApprovalsData, isLoading: isPendingLoading } = useQuery({
    queryKey: ['pending-approvals'],
    queryFn: () => approvalService.getPendingApprovals(),
    enabled: user?.role === 'manager' || user?.role === 'admin',
  });

  const { data: approvalStatsData } = useQuery({
    queryKey: ['approval-stats'],
    queryFn: () => approvalService.getApprovalStats(),
    enabled: user?.role === 'manager' || user?.role === 'admin',
  });

  const stats = dashboardData?.data?.stats;
  const recentInvoices = dashboardData?.data?.recentInvoices || [];
  const pendingInvoices = pendingApprovalsData?.data?.pendingInvoices || [];
  const approvalStats = approvalStatsData?.data;

  const handleApprove = async (invoiceId: string, notes?: string) => {
    try {
      await approvalService.processApproval(invoiceId, {
        action: 'approve',
        notes,
      });
      // Refresh data
      window.location.reload();
    } catch (error) {
      console.error('Approval error:', error);
    }
  };

  const handleReject = async (invoiceId: string, reason: string, notes?: string) => {
    try {
      await approvalService.processApproval(invoiceId, {
        action: 'reject',
        notes: notes || reason,
      });
      // Refresh data
      window.location.reload();
    } catch (error) {
      console.error('Rejection error:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="mt-2 text-gray-600">
          Welcome back, {user?.firstName}! Here's what's happening with your invoices.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
        <StatsCard
          title="Total Invoices"
          value={stats?.totalInvoices || 0}
          icon={<FileText className="w-6 h-6" />}
          color="blue"
          loading={isDashboardLoading}
        />
        <StatsCard
          title="Pending"
          value={stats?.pendingInvoices || 0}
          icon={<Clock className="w-6 h-6" />}
          color="yellow"
          loading={isDashboardLoading}
        />
        <StatsCard
          title="Approved"
          value={stats?.approvedInvoices || 0}
          icon={<CheckCircle className="w-6 h-6" />}
          color="green"
          loading={isDashboardLoading}
        />
        <StatsCard
          title="Rejected"
          value={stats?.rejectedInvoices || 0}
          icon={<XCircle className="w-6 h-6" />}
          color="red"
          loading={isDashboardLoading}
        />
        <StatsCard
          title="Total Amount"
          value={`$${(stats?.totalAmount || 0).toLocaleString()}`}
          icon={<DollarSign className="w-6 h-6" />}
          color="blue"
          loading={isDashboardLoading}
        />
        <StatsCard
          title="Overdue"
          value={stats?.overdueInvoices || 0}
          icon={<AlertTriangle className="w-6 h-6" />}
          color="red"
          loading={isDashboardLoading}
        />
      </div>

      {/* Approval Stats for Managers/Admins */}
      {(user?.role === 'manager' || user?.role === 'admin') && approvalStats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatsCard
            title="Total Approvals"
            value={approvalStats.totalApprovals}
            icon={<CheckCircle className="w-6 h-6" />}
            color="green"
          />
          <StatsCard
            title="This Month"
            value={approvalStats.monthlyApprovals}
            icon={<Calendar className="w-6 h-6" />}
            color="blue"
          />
          <StatsCard
            title="Avg. Approval Time"
            value={`${approvalStats.averageApprovalTimeHours.toFixed(1)}h`}
            icon={<Clock className="w-6 h-6" />}
            color="yellow"
          />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Invoices */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Invoices</CardTitle>
          </CardHeader>
          <CardContent>
            {isDashboardLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-20 bg-gray-200 rounded"></div>
                  </div>
                ))}
              </div>
            ) : recentInvoices.length > 0 ? (
              <div className="space-y-4">
                {recentInvoices.slice(0, 5).map((invoice) => (
                  <InvoiceCard
                    key={invoice.id}
                    invoice={invoice}
                    compact
                    onView={(id) => console.log('View invoice:', id)}
                  />
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">No recent invoices</p>
            )}
          </CardContent>
        </Card>

        {/* Pending Approvals for Managers/Admins */}
        {(user?.role === 'manager' || user?.role === 'admin') && (
          <Card>
            <CardHeader>
              <CardTitle>Pending Approvals</CardTitle>
            </CardHeader>
            <CardContent>
              {isPendingLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="h-20 bg-gray-200 rounded"></div>
                    </div>
                  ))}
                </div>
              ) : pendingInvoices.length > 0 ? (
                <div className="space-y-4">
                  {pendingInvoices.slice(0, 5).map((invoice) => (
                    <InvoiceCard
                      key={invoice.id}
                      invoice={invoice}
                      compact
                      onApprove={handleApprove}
                      onReject={handleReject}
                      onView={(id) => console.log('View invoice:', id)}
                    />
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">
                  No pending approvals
                </p>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};