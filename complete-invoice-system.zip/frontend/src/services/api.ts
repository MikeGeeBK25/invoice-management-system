import {
  User,
  LoginCredentials,
  ApiResponse,
  Invoice,
  InvoiceFilters,
  PaginatedResponse,
  DashboardStats,
  CreateInvoiceData,
  ApprovalRequest,
  ApprovalWorkflow,
} from '@/types';

const API_BASE_URL = (import.meta as any).env?.VITE_API_BASE_URL || '/api';

class ApiClient {
  private getAuthHeaders(): HeadersInit {
    const token = JSON.parse(localStorage.getItem('auth-storage') || '{}')?.state?.token;
    return {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
    };
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    const url = `${API_BASE_URL}${endpoint}`;
    const config: RequestInit = {
      headers: this.getAuthHeaders(),
      ...options,
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error?.message || 'Request failed');
      }
      
      return data;
    } catch (error) {
      console.error('API request error:', error);
      throw error;
    }
  }

  get<T>(endpoint: string): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, { method: 'GET' });
  }

  post<T>(endpoint: string, data?: any): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  put<T>(endpoint: string, data?: any): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  delete<T>(endpoint: string): Promise<ApiResponse<T>> {
    return this.request<T>(endpoint, { method: 'DELETE' });
  }
}

const apiClient = new ApiClient();

export const authService = {
  login: (credentials: LoginCredentials): Promise<ApiResponse<{ user: User; token: string; refreshToken: string }>> =>
    apiClient.post('/auth/login', credentials),
  
  logout: (refreshToken: string): Promise<ApiResponse> =>
    apiClient.post('/auth/logout', { refreshToken }),
  
  refreshToken: (refreshToken: string): Promise<ApiResponse<{ token: string; refreshToken: string }>> =>
    apiClient.post('/auth/refresh', { refreshToken }),
};

export const invoiceService = {
  getInvoices: (filters?: InvoiceFilters): Promise<ApiResponse<PaginatedResponse<Invoice>>> => {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.vendor) params.append('vendor', filters.vendor);
    if (filters?.department) params.append('department', filters.department);
    if (filters?.priority) params.append('priority', filters.priority);
    if (filters?.limit) params.append('limit', filters.limit.toString());
    if (filters?.offset) params.append('offset', filters.offset.toString());
    if (filters?.sortBy) params.append('sortBy', filters.sortBy);
    if (filters?.sortOrder) params.append('sortOrder', filters.sortOrder);
    
    const queryString = params.toString();
    return apiClient.get(`/invoices${queryString ? `?${queryString}` : ''}`);
  },

  getInvoiceById: (id: string): Promise<ApiResponse<{ invoice: Invoice }>> =>
    apiClient.get(`/invoices/${id}`),

  createInvoice: (data: CreateInvoiceData): Promise<ApiResponse<{ invoice: Invoice }>> =>
    apiClient.post('/invoices', data),

  updateInvoiceStatus: (id: string, status: string, assignedTo?: string): Promise<ApiResponse<{ invoice: Invoice }>> =>
    apiClient.put(`/invoices/${id}/status`, { status, assignedTo }),

  getDashboardStats: (): Promise<ApiResponse<{ stats: DashboardStats; recentInvoices: Invoice[] }>> =>
    apiClient.get('/invoices/dashboard'),
};

export const approvalService = {
  processApproval: (invoiceId: string, approval: ApprovalRequest): Promise<ApiResponse<{ invoice: Invoice; workflow: ApprovalWorkflow }>> =>
    apiClient.post(`/approvals/${invoiceId}`, approval),

  getApprovalHistory: (invoiceId: string): Promise<ApiResponse<{ approvalHistory: ApprovalWorkflow[] }>> =>
    apiClient.get(`/approvals/history/${invoiceId}`),

  getPendingApprovals: (): Promise<ApiResponse<{ pendingInvoices: Invoice[] }>> =>
    apiClient.get('/approvals/pending'),

  getApprovalStats: (): Promise<ApiResponse<{ totalApprovals: number; monthlyApprovals: number; averageApprovalTimeHours: number }>> =>
    apiClient.get('/approvals/stats'),
};

export const vendorService = {
  getVendors: (filters?: any): Promise<ApiResponse<PaginatedResponse<any>>> => {
    const params = new URLSearchParams();
    if (filters?.isApproved !== undefined) params.append('isApproved', filters.isApproved.toString());
    if (filters?.search) params.append('search', filters.search);
    if (filters?.limit) params.append('limit', filters.limit.toString());
    if (filters?.offset) params.append('offset', filters.offset.toString());
    
    const queryString = params.toString();
    return apiClient.get(`/vendors${queryString ? `?${queryString}` : ''}`);
  },

  getVendorById: (id: string): Promise<ApiResponse<{ vendor: any }>> =>
    apiClient.get(`/vendors/${id}`),

  createVendor: (data: any): Promise<ApiResponse<{ vendor: any }>> =>
    apiClient.post('/vendors', data),

  updateVendor: (id: string, data: any): Promise<ApiResponse<{ vendor: any }>> =>
    apiClient.put(`/vendors/${id}`, data),

  approveVendor: (id: string): Promise<ApiResponse<{ vendor: any }>> =>
    apiClient.put(`/vendors/${id}/approve`, {}),

  getVendorStats: (): Promise<ApiResponse<any>> =>
    apiClient.get('/vendors/stats'),
};

export const uploadService = {
  uploadFiles: (formData: FormData): Promise<ApiResponse<{ files: any[]; totalFiles: number }>> => {
    const token = JSON.parse(localStorage.getItem('auth-storage') || '{}')?.state?.token;
    return fetch('/api/uploads/files', {
      method: 'POST',
      headers: {
        ...(token && { Authorization: `Bearer ${token}` }),
      },
      body: formData,
    }).then(res => res.json());
  },

  createInvoiceFromUpload: (data: any): Promise<ApiResponse<{ invoice: Invoice }>> =>
    apiClient.post('/uploads/create-invoice', data),

  deleteFile: (filename: string): Promise<ApiResponse<{ message: string }>> =>
    apiClient.delete(`/uploads/${filename}`),
};

export default apiClient;