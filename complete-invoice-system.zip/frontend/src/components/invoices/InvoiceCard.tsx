import React from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Invoice, PriorityLevel, InvoiceStatus } from '@/types';
import { format } from 'date-fns';
import { 
  Building2, 
  Calendar, 
  DollarSign, 
  AlertCircle,
  CheckCircle,
  XCircle,
  Clock
} from 'lucide-react';

interface InvoiceCardProps {
  invoice: Invoice;
  onApprove?: (id: string, notes?: string) => void;
  onReject?: (id: string, reason: string, notes?: string) => void;
  onView?: (id: string) => void;
  compact?: boolean;
}

const priorityColors: Record<PriorityLevel, string> = {
  low: 'bg-gray-100 text-gray-800',
  medium: 'bg-blue-100 text-blue-800',
  high: 'bg-orange-100 text-orange-800',
  urgent: 'bg-red-100 text-red-800',
};

const statusColors: Record<InvoiceStatus, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  in_review: 'bg-blue-100 text-blue-800',
  approved: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800',
  paid: 'bg-green-100 text-green-800',
  cancelled: 'bg-gray-100 text-gray-800',
};

const statusIcons: Record<InvoiceStatus, React.ReactNode> = {
  pending: <Clock className="w-4 h-4" />,
  in_review: <AlertCircle className="w-4 h-4" />,
  approved: <CheckCircle className="w-4 h-4" />,
  rejected: <XCircle className="w-4 h-4" />,
  paid: <CheckCircle className="w-4 h-4" />,
  cancelled: <XCircle className="w-4 h-4" />,
};

export const Badge: React.FC<{ 
  children: React.ReactNode; 
  className?: string; 
  variant?: 'default' | 'success' | 'warning' | 'danger';
}> = ({ children, className, variant = 'default' }) => {
  const variants = {
    default: 'bg-gray-100 text-gray-800',
    success: 'bg-green-100 text-green-800',
    warning: 'bg-yellow-100 text-yellow-800',
    danger: 'bg-red-100 text-red-800',
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${variants[variant]} ${className}`}>
      {children}
    </span>
  );
};

export const InvoiceCard: React.FC<InvoiceCardProps> = ({
  invoice,
  onApprove,
  onReject,
  onView,
  compact = false,
}) => {
  const isOverdue = new Date(invoice.dueDate) < new Date() && 
    ['pending', 'in_review', 'approved'].includes(invoice.status);

  const canApprove = invoice.status === 'pending' || invoice.status === 'in_review';

  return (
    <Card className={`transition-all duration-200 hover:shadow-md ${compact ? 'p-4' : ''}`}>
      <div className="flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2 mb-2">
            <h3 className="text-lg font-semibold text-gray-900 truncate">
              {invoice.invoiceNumber}
            </h3>
            <Badge className={priorityColors[invoice.priority]}>
              {invoice.priority}
            </Badge>
            {isOverdue && (
              <Badge variant="danger">
                Overdue
              </Badge>
            )}
          </div>

          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
            <div className="flex items-center">
              <Building2 className="w-4 h-4 mr-1" />
              <span className="truncate">{invoice.vendor.name}</span>
            </div>
            <div className="flex items-center">
              <DollarSign className="w-4 h-4 mr-1" />
              <span className="font-medium">
                {invoice.currency} {invoice.totalAmount.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center">
              <Calendar className="w-4 h-4 mr-1" />
              <span>Due {format(new Date(invoice.dueDate), 'MMM d, yyyy')}</span>
            </div>
          </div>

          {!compact && (
            <div className="space-y-2 text-sm">
              {invoice.description && (
                <p className="text-gray-600 line-clamp-2">{invoice.description}</p>
              )}
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-gray-500">Submitted by:</span>
                  <span className="text-gray-900">
                    {invoice.submitter.firstName} {invoice.submitter.lastName}
                  </span>
                </div>
                
                {invoice.confidenceScore > 0 && (
                  <div className="flex items-center space-x-1">
                    <span className="text-gray-500">AI Confidence:</span>
                    <span className={`font-medium ${
                      invoice.confidenceScore >= 95 ? 'text-green-600' :
                      invoice.confidenceScore >= 85 ? 'text-yellow-600' :
                      'text-red-600'
                    }`}>
                      {invoice.confidenceScore}%
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-col items-end space-y-2 ml-4">
          <div className="flex items-center">
            {statusIcons[invoice.status]}
            <Badge className={`ml-2 ${statusColors[invoice.status]}`}>
              {invoice.status.replace('_', ' ')}
            </Badge>
          </div>

          <div className="flex space-x-2">
            {onView && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => onView(invoice.id)}
              >
                View
              </Button>
            )}
            
            {canApprove && onApprove && (
              <Button
                variant="success"
                size="sm"
                onClick={() => onApprove(invoice.id)}
              >
                Approve
              </Button>
            )}
            
            {canApprove && onReject && (
              <Button
                variant="danger"
                size="sm"
                onClick={() => onReject(invoice.id, 'Rejected by user')}
              >
                Reject
              </Button>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
};