import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Button } from '@/components/ui/Button';
import { Card, CardContent } from '@/components/ui/Card';
import { 
  Upload, 
  File, 
  X, 
  CheckCircle, 
  AlertCircle
} from 'lucide-react';
import { clsx } from 'clsx';

interface FileWithPreview extends File {
  preview?: string;
  id: string;
}

interface UploadMetadata {
  department?: string;
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  category?: string;
}

interface FileUploadProps {
  onUpload: (files: File[], metadata: UploadMetadata) => Promise<void>;
  maxFiles?: number;
  acceptedTypes?: string[];
  maxSize?: number;
  metadata?: UploadMetadata;
  onMetadataChange?: (metadata: UploadMetadata) => void;
}

export const FileUpload: React.FC<FileUploadProps> = ({
  onUpload,
  maxFiles = 5,
  acceptedTypes = ['image/jpeg', 'image/png', 'application/pdf'],
  maxSize = 10 * 1024 * 1024, // 10MB
  metadata = {},
  onMetadataChange,
}) => {
  const [files, setFiles] = useState<FileWithPreview[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const onDrop = useCallback((acceptedFiles: File[], rejectedFiles: any[]) => {
    // Handle rejected files
    if (rejectedFiles.length > 0) {
      const errors = rejectedFiles.map(({ file, errors }) => 
        `${file.name}: ${errors.map((e: any) => e.message).join(', ')}`
      );
      alert(`Some files were rejected:\n${errors.join('\n')}`);
    }

    // Add accepted files
    const newFiles = acceptedFiles.map(file => ({
      ...file,
      id: Math.random().toString(36).substr(2, 9),
      preview: file.type.startsWith('image/') ? URL.createObjectURL(file) : undefined,
    }));

    setFiles(prev => [...prev, ...newFiles].slice(0, maxFiles));
    setUploadStatus('idle');
  }, [maxFiles]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: acceptedTypes.reduce((acc, type) => ({ ...acc, [type]: [] }), {}),
    maxSize,
    multiple: true,
    maxFiles,
  });

  const removeFile = (fileId: string) => {
    setFiles(prev => {
      const updated = prev.filter(file => file.id !== fileId);
      // Revoke object URLs to prevent memory leaks
      const fileToRemove = prev.find(file => file.id === fileId);
      if (fileToRemove?.preview) {
        URL.revokeObjectURL(fileToRemove.preview);
      }
      return updated;
    });
  };

  const handleUpload = async () => {
    if (files.length === 0) return;

    setUploading(true);
    setUploadStatus('idle');

    try {
      await onUpload(files, metadata);
      setUploadStatus('success');
      setFiles([]);
    } catch (error) {
      console.error('Upload error:', error);
      setUploadStatus('error');
    } finally {
      setUploading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) {
      return (file as any).preview ? (
        <img
          src={(file as any).preview}
          alt={file.name}
          className="w-8 h-8 object-cover rounded"
        />
      ) : null;
    }
    return <File className="w-8 h-8 text-gray-400" />;
  };

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <Card>
        <CardContent className="p-6">
          <div
            {...getRootProps()}
            className={clsx(
              'border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors',
              isDragActive
                ? 'border-primary-500 bg-primary-50'
                : 'border-gray-300 hover:border-gray-400',
              uploading && 'pointer-events-none opacity-50'
            )}
          >
            <input {...getInputProps()} />
            <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            {isDragActive ? (
              <p className="text-lg text-primary-600">Drop the files here...</p>
            ) : (
              <div>
                <p className="text-lg text-gray-600 mb-2">
                  Drag & drop files here, or click to select
                </p>
                <p className="text-sm text-gray-500">
                  Supports: {acceptedTypes.map(type => {
                    if (type === 'application/pdf') return 'PDF';
                    if (type === 'image/jpeg') return 'JPEG';
                    if (type === 'image/png') return 'PNG';
                    return type;
                  }).join(', ')} • Max {formatFileSize(maxSize)} per file • Up to {maxFiles} files
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Metadata Form */}
      {onMetadataChange && (
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Upload Options</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Department
                </label>
                <select
                  value={metadata.department || ''}
                  onChange={(e) => onMetadataChange({ ...metadata, department: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="">Select Department</option>
                  <option value="Finance">Finance</option>
                  <option value="Operations">Operations</option>
                  <option value="IT">IT</option>
                  <option value="Marketing">Marketing</option>
                  <option value="HR">HR</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Priority
                </label>
                <select
                  value={metadata.priority || 'medium'}
                  onChange={(e) => onMetadataChange({ ...metadata, priority: e.target.value as any })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select
                  value={metadata.category || ''}
                  onChange={(e) => onMetadataChange({ ...metadata, category: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="">Select Category</option>
                  <option value="Software">Software</option>
                  <option value="Hardware">Hardware</option>
                  <option value="Consulting">Consulting</option>
                  <option value="Office Supplies">Office Supplies</option>
                  <option value="Travel">Travel</option>
                  <option value="Utilities">Utilities</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* File List */}
      {files.length > 0 && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Selected Files ({files.length})</h3>
              <Button
                onClick={handleUpload}
                disabled={uploading || files.length === 0}
                loading={uploading}
              >
                {uploading ? 'Processing...' : 'Upload & Process'}
              </Button>
            </div>

            <div className="space-y-3">
              {files.map((file) => (
                <div
                  key={file.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                >
                  <div className="flex items-center space-x-3">
                    {getFileIcon(file)}
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {file.name}
                      </p>
                      <p className="text-sm text-gray-500">
                        {formatFileSize(file.size)}
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => removeFile(file.id)}
                    disabled={uploading}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Upload Status */}
      {uploadStatus !== 'idle' && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              {uploadStatus === 'success' && (
                <>
                  <CheckCircle className="w-6 h-6 text-green-500" />
                  <div>
                    <p className="text-sm font-medium text-green-800">
                      Files uploaded successfully!
                    </p>
                    <p className="text-sm text-green-600">
                      AI data extraction completed. Review the extracted information before creating invoices.
                    </p>
                  </div>
                </>
              )}
              {uploadStatus === 'error' && (
                <>
                  <AlertCircle className="w-6 h-6 text-red-500" />
                  <div>
                    <p className="text-sm font-medium text-red-800">
                      Upload failed
                    </p>
                    <p className="text-sm text-red-600">
                      Please try again or contact support if the problem persists.
                    </p>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};