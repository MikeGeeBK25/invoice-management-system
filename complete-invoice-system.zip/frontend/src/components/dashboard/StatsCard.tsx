import React from 'react';
import { Card } from '@/components/ui/Card';
import { clsx } from 'clsx';

interface StatsCardProps {
  title: string;
  value: string | number;
  change?: number;
  icon?: React.ReactNode;
  color?: 'blue' | 'green' | 'red' | 'yellow';
  loading?: boolean;
}

export const StatsCard: React.FC<StatsCardProps> = ({
  title,
  value,
  change,
  icon,
  color = 'blue',
  loading = false,
}) => {
  const colorStyles = {
    blue: 'text-primary-600 bg-primary-50',
    green: 'text-success-600 bg-success-50',
    red: 'text-danger-600 bg-danger-50',
    yellow: 'text-warning-600 bg-warning-50',
  };

  if (loading) {
    return (
      <Card>
        <div className="animate-pulse">
          <div className="flex items-center">
            <div className="p-2 rounded-lg bg-gray-200 w-10 h-10"></div>
            <div className="ml-4 flex-1">
              <div className="h-4 bg-gray-200 rounded w-20 mb-2"></div>
              <div className="h-6 bg-gray-200 rounded w-16"></div>
            </div>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card>
      <div className="flex items-center">
        {icon && (
          <div className={clsx('p-2 rounded-lg', colorStyles[color])}>
            {icon}
          </div>
        )}
        <div className={clsx('flex-1', icon && 'ml-4')}>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <div className="flex items-center mt-1">
            <p className="text-2xl font-semibold text-gray-900">
              {typeof value === 'number' ? value.toLocaleString() : value}
            </p>
            {change !== undefined && (
              <span
                className={clsx(
                  'ml-2 text-sm font-medium',
                  change >= 0 ? 'text-success-600' : 'text-danger-600'
                )}
              >
                {change >= 0 ? '+' : ''}
                {change}%
              </span>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
};