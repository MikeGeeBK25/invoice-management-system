import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { AuthState, LoginCredentials, User } from '@/types';
import { authService } from '@/services/api';

interface AuthActions {
  login: (credentials: LoginCredentials) => Promise<boolean>;
  logout: () => void;
  refreshTokenFn: () => Promise<boolean>;
  setUser: (user: User) => void;
  clearAuth: () => void;
}

export const useAuthStore = create<AuthState & AuthActions>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      refreshToken: null,
      isAuthenticated: false,
      isLoading: false,

      login: async (credentials) => {
        set({ isLoading: true });
        try {
          const response = await authService.login(credentials);
          if (response.success && response.data) {
            const { user, token, refreshToken } = response.data;
            set({
              user,
              token,
              refreshToken,
              isAuthenticated: true,
              isLoading: false,
            });
            return true;
          }
          set({ isLoading: false });
          return false;
        } catch (error) {
          set({ isLoading: false });
          return false;
        }
      },

      logout: () => {
        const { refreshToken } = get();
        if (refreshToken) {
          try {
            authService.logout(refreshToken);
          } catch (error) {
            console.error('Logout error:', error);
          }
        }
        set({
          user: null,
          token: null,
          refreshToken: null,
          isAuthenticated: false,
          isLoading: false,
        });
      },

      refreshTokenFn: async () => {
        const { refreshToken } = get();
        if (!refreshToken) return false;

        try {
          const response = await authService.refreshToken(refreshToken);
          if (response.success && response.data) {
            const { token, refreshToken: newRefreshToken } = response.data;
            set({
              token,
              refreshToken: newRefreshToken,
            });
            return true;
          }
          get().clearAuth();
          return false;
        } catch (error) {
          get().clearAuth();
          return false;
        }
      },

      setUser: (user) => set({ user }),

      clearAuth: () => set({
        user: null,
        token: null,
        refreshToken: null,
        isAuthenticated: false,
        isLoading: false,
      }),
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        token: state.token,
        refreshToken: state.refreshToken,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);