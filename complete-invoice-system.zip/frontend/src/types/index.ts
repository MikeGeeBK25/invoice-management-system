export type UserRole = 'admin' | 'manager' | 'user' | 'viewer';

export type InvoiceStatus = 'pending' | 'in_review' | 'approved' | 'rejected' | 'paid' | 'cancelled';

export type PriorityLevel = 'low' | 'medium' | 'high' | 'urgent';

export type WorkflowAction = 'submit' | 'approve' | 'reject' | 'request_info' | 'escalate';

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  department?: string;
  approvalLimit: number;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface LoginResponse {
  success: boolean;
  data: {
    user: User;
    token: string;
    refreshToken: string;
  };
}

export interface Vendor {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country: string;
  taxId?: string;
  paymentTerms: number;
  isApproved: boolean;
  riskScore: number;
  createdAt: string;
  updatedAt: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  vendor: Vendor;
  amount: number;
  taxAmount: number;
  totalAmount: number;
  currency: string;
  invoiceDate: string;
  dueDate: string;
  description?: string;
  poNumber?: string;
  department?: string;
  category?: string;
  status: InvoiceStatus;
  priority: PriorityLevel;
  confidenceScore: number;
  aiExtractedData?: any;
  originalFileUrl?: string;
  processedFileUrl?: string;
  submitter: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
  };
  assignee?: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface ApprovalWorkflow {
  id: string;
  invoiceId: string;
  approver: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    role: UserRole;
  };
  stepNumber: number;
  action: WorkflowAction;
  timestamp: string;
  notes?: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface InvoiceFilters {
  status?: InvoiceStatus;
  vendor?: string;
  department?: string;
  priority?: PriorityLevel;
  limit?: number;
  offset?: number;
  sortBy?: 'created_at' | 'due_date' | 'amount';
  sortOrder?: 'asc' | 'desc';
}

export interface DashboardStats {
  totalInvoices: number;
  pendingInvoices: number;
  approvedInvoices: number;
  rejectedInvoices: number;
  totalAmount: number;
  overdueInvoices: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    total: number;
    limit: number;
    offset: number;
    hasMore: boolean;
  };
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
}

export interface CreateInvoiceData {
  invoiceNumber: string;
  vendorId: string;
  amount: number;
  taxAmount?: number;
  invoiceDate: string;
  dueDate: string;
  description?: string;
  poNumber?: string;
  department?: string;
  category?: string;
  priority?: PriorityLevel;
}

export interface ApprovalRequest {
  action: WorkflowAction;
  notes?: string;
}